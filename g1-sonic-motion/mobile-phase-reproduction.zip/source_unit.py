"""Synthetic pixels/proprio exercise the real public subprocess and actual mode switch without a native reset."""
from contextlib import ExitStack
import base64
from pathlib import Path
import io

from PIL import Image
import numpy as np

from runner import source_wire, MobilePolicy, Episode, practice, inspect, ASSETS, digest
from mobile_io import stamp_observation

def main():
    inspect()
    for line in Path('/opt/sonic/public_assets.sha256').read_text().splitlines():
        if line and not line.startswith('#'):
            h,n=line.split(maxsplit=1)
            assert digest(ASSETS/n)==h,n
    raw=io.BytesIO()
    Image.new('RGB',(128,96),(64,96,128)).save(raw,'PNG')
    sample=base64.b64encode(raw.getvalue()).decode()
    names=('hand','side','overview')
    obs={k:[0.]*3 for k in ['base_pos','base_gyro','gravity_body','left_hand_pos','right_hand_pos','torso_pos']}
    obs.update(q=[0.]*29,dq=[0.]*29,base_quat=[1.,0.,0.,0.],torso_quat=[1.,0.,0.,0.])
    previous=None
    with ExitStack() as stack:
        stock=source_wire(stack); policy=Episode(MobilePolicy(),'v4')
        witnesses=[]
        for tick in range(0,266,5):
            packet=stamp_observation(dict(protocol='g1-sonic-mobile-rgb/1',tick=tick,task='box_to_pad',
                   observation=obs,decoder_history=[0.]*930,last_hand=[0.,0.],last_observation_id=previous,
                   vision=dict(tick=tick,mime='image/png',images={k:sample for k in names},
                               calibration={k:{'width':128,'height':96} for k in names})))
            rows=policy.act({'type':'act','t':tick,'obs':packet})['rows']
            assert practice.ask(stock,packet,1100)==rows
            previous=packet['observation_id']
            witnesses.append(policy.pending[previous][0][0])
        assert np.array_equal(np.flatnonzero(witnesses),[50,51,52,53])
    print('Synthetic real stock wire and phase-switch parity: exact 54 chunks / 270 offered rows, switched at t=250; all asset bytes verified.')
if __name__=='__main__':main()
