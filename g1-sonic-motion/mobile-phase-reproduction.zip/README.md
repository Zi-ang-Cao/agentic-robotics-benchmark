# Rebuild and compare the mobile phase-cap study

The original study used Docker image `sha256:120adc0ca0e2d94a4b74379bb4724f3cc51149a991662634c4a712ea6bfc452f`. This kit compares a locally rebuilt image against the recorded numerical stack and all public assets. Source calibration then checks the stock solver on the known public case. A final comparison covers every registered trajectory and native replay. Each local execution records its real image ID and writes into a new directory.

## Build and inspect the local image

Run from a freshly extracted kit on Linux x86-64 with Docker and host Python 3.10 or later. Select a physical CPU available to the container at launch.

```bash
git clone https://github.com/Zi-ang-Cao/agentic-robotics-benchmark.git ../mobile-benchmark
git -C ../mobile-benchmark fetch origin 62279a89db9bd4ab6d8da88b01ade40a255b7515
git -C ../mobile-benchmark worktree add --detach ../mobile-frozen 62279a89db9bd4ab6d8da88b01ade40a255b7515
envdir=../mobile-frozen/tasks/humanoid/g1_sonic_mobile_pick_place/environment
docker build --platform linux/amd64 -f "$envdir/Dockerfile" -t mobile-phase-cap:rebuilt "$envdir"
python3 portable_recipe.py check --image mobile-phase-cap:rebuilt
```

The environment directory is the Docker build context. Its Dockerfile copies the requirements, asset fetcher and manifest, native Python simulator and mobile I/O. The build fetches the public robot, encoder and decoder. The pinned task's solution directory supplies the controller and is extracted separately from Git before launch.

## Run and verify a fresh reproduction

```bash
python3 portable_recipe.py reproduce --image mobile-phase-cap:rebuilt --checkout ../mobile-benchmark --cpu 0 --out ../mobile-reproduction-01
```

The check command reads the selected image by actual content ID and compares measured BLAS output, runtime environment, installed wheel payloads, Mesa/EGL libraries, public native source and all manifest-listed assets to `recorded_environment.json`. Passing this check establishes runtime agreement on these measurements. The synthetic source unit is included; its original entry point requires the original image ID. On a distinct image the supplemental launcher runs the frozen transform tests and independently rechecks source and runtime identity, then calls the same unmodified native calibration, recording and replay functions. It supplies Docker's actual inspected ID throughout.

The full run verifies the stock public solver at cylinder practice seed 19 before allocating the 48 study assignments. It checks 49 complete typed-array and physical trajectory signatures against the published ledger, including the calibration. The local sidecar `reproduction_result.json` records both IDs, result hashes, mismatch labels and the final comparison status. The local result JSON includes measured timings, which can differ between executions. The source CLIs retain the rendering and physics responsibilities of their registered procedures. Checksums for the contents of this kit are in `sha256.json`.
