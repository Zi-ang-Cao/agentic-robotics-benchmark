"""Build an independent reproduction kit or run it against an honestly identified Docker image."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parent
RECORDED = 'sha256:120adc0ca0e2d94a4b74379bb4724f3cc51149a991662634c4a712ea6bfc452f'
PROTOCOL = 'b41dd3327101feaf02be13749cdce2ff73c7ebdc0163fbe975a5348f7ca65382'
IMPLEMENTATION = ('implementation.json','analysis_freeze.json','protocol.json','freeze.py','run.sh','runner.py',
                  'source_unit.py','summarize.py','report.py','calibration_source/public-cli-cylinder19.json')
SOURCE = 'https://github.com/Zi-ang-Cao/agentic-robotics-benchmark.git'
ENV_KEYS = ('OPENBLAS_CORETYPE','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NPY_DISABLE_CPU_FEATURES',
            'GALLIUM_DRIVER','LIBGL_ALWAYS_SOFTWARE','LP_NUM_THREADS','PYOPENGL_PLATFORM','MUJOCO_GL','EGL_PLATFORM','__EGL_VENDOR_LIBRARY_FILENAMES')


def require(test,label):
    if not test:
        raise ValueError(label)


def hash_file(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()


def encoded(x):
    return (json.dumps(x,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()


def signature(x):
    return hashlib.sha256(encoded(x)).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def store(p,x):
    data=encoded(x)
    if p.exists():
        require(p.read_bytes()==data,'different existing sidecar '+str(p))
    else:
        with p.open('xb') as f:f.write(data)


def check_sources(root):
    plan=read(root/'protocol.json')
    require(hash_file(root/'protocol.json')==PROTOCOL and plan['image']==RECORDED,'frozen protocol')
    hashes={**read(root/'implementation.json')['sha256'],**read(root/'analysis_freeze.json')['analysis_only_files']}
    hashes['calibration_source/public-cli-cylinder19.json']=plan['source_control_sha256']
    for name,digest in hashes.items():require(hash_file(root/name)==digest,name)
    return plan


def stack(protocol):
    """Run inside an image. Read installed files and exercise BLAS; creates no native world or renderer."""
    import numpy as np
    require(hash_file(protocol)==PROTOCOL,'stack protocol')
    plan=read(protocol)
    native=Path('/opt/sonic')
    files={n:h for n,h in plan['task_source_sha256'].items()
           if n.startswith(('environment/sonic_sim/','environment/mobile_io.py','environment/public_assets.sha256'))}
    for n,h in files.items():require(hash_file(native/n.removeprefix('environment/'))==h,n)
    assets={}
    for line in (native/'public_assets.sha256').read_text().splitlines():
        if line and not line.startswith('#'):
            digest,name=line.split(maxsplit=1);require(hash_file(native/'assets'/name)==digest,name);assets[name]=digest
    require(assets['policy/model_decoder.onnx']==plan['decoder_sha256'],'decoder')
    packages={}
    for name in ('numpy','scipy','onnxruntime','mujoco','Pillow'):
        dist=importlib.metadata.distribution(name)
        # Includes wheel-provided art (MuJoCo), Python source, extensions, bundled BLAS/LAPACK and run-time shared libraries.
        payload={str(f):hash_file(dist.locate_file(f)) for f in dist.files
                 if f.hash is not None and '.dist-info/' not in str(f) and not str(f).startswith('../') and not str(f).endswith('.pyc')}
        require(payload,name+' package files')
        packages[name]=dict(version=dist.version,files=len(payload),payload_sha256=signature(payload))
    lib=Path('/usr/lib/x86_64-linux-gnu')
    mesa={}
    for name in ('libEGL.so.1','libEGL_mesa.so.0','libGLdispatch.so.0','dri/swrast_dri.so'):
        mesa[name]=hash_file(lib/name)
    dpkg=subprocess.check_output(['dpkg-query','-W','-f=${Package}=${Version}\n',
          'libegl-mesa0','libegl1','libgl1-mesa-dri','libglvnd0','libc6'],text=True)
    i=np.arange(71*97,dtype=np.int64);j=np.arange(97*53,dtype=np.int64)
    a=((i*31337+11)%3299-1649).reshape(71,97)/1291.
    b=((j*30757+17)%3511-1755).reshape(97,53)/1303.
    blas=hashlib.sha256(np.asarray(a@b,dtype='<f8').tobytes()).hexdigest()
    require(blas=='f83f8230aa5e4c8b0e595efe592952b387120788d96d7aed3696fea03728c0cc','BLAS float64 witness')
    return dict(machine=platform.machine(),python=sys.version,interpreter_sha256=hash_file(Path(sys.executable)),
                libc=list(platform.libc_ver()),os_release_sha256=hash_file(Path('/etc/os-release')),runtime_env={k:os.environ[k] for k in ENV_KEYS},
                packages=packages,os_packages=sorted(dpkg.splitlines()),mesa_binaries=mesa,egl_vendor_sha256=hash_file(Path(os.environ[ENV_KEYS[-1]])),
                blas_measured_sha256=blas,installed_native_source_sha256=signature(files),public_assets_sha256=signature(assets),asset_count=len(assets))


def image_info(image):
    i=json.loads(subprocess.check_output(['docker','image','inspect',image]))[0]
    return dict(id=i['Id'],os=i['Os'],architecture=i['Architecture'],rootfs_layers_sha256=signature(i['RootFS']['Layers']))


def docker_probe(image,root):
    info=image_info(image)
    require((info['os'],info['architecture'])==('linux','amd64'),'Linux amd64 image required')
    cmd=['docker','run','--rm','--read-only','--network','none','--cpus=1','--user',f'{os.getuid()}:{os.getgid()}',
         '--tmpfs','/tmp:rw,exec','--mount',f'type=bind,src={Path(__file__).resolve()},dst=/probe.py,readonly',
         '--mount',f'type=bind,src={root/"protocol.json"},dst=/protocol.json,readonly','--entrypoint','/opt/venv/bin/python3',
         info['id'],'-B','-I','/probe.py','_probe']
    return dict(image=info,stack=json.loads(subprocess.check_output(cmd)),protocol_sha256=PROTOCOL)


def compare_stack(root,image):
    expected=read(root/'recorded_environment.json')
    require(expected['image']['id']==RECORDED and expected['protocol_sha256']==PROTOCOL,'recorded image provenance')
    observed=docker_probe(image,root)
    differences=sorted(k for k in expected['stack'].keys()|observed['stack'].keys() if expected['stack'].get(k)!=observed['stack'].get(k))
    require(not differences,'Runtime fingerprint differs in '+', '.join(differences))
    return observed


def phase(root):
    """Dispatch frozen functions after checking every source/asset binding and the real local runtime."""
    import runner
    plan=check_sources(root)
    identity=read(root/'local_environment.json')
    require(os.environ['STUDY_IMAGE_ID']==identity['image']['id'],'real local image ID')
    require(identity['stack']==read(root/'recorded_environment.json')['stack']==stack(root/'protocol.json'),'actual local stack')
    for n,h in plan['task_source_sha256'].items():require(hash_file(root/'snapshot'/n)==h,n)
    runner.safety_tests()
    if identity['image']['id']==RECORDED:
        import source_unit
        source_unit.main()
    runner.run_one('calibration',runner.SOURCE,'native')
    folder=root/'calibration/cylinder-practice19-native'
    runner.complete(folder,runner.SOURCE,'native')
    cal=read(folder/'original.json');replay=read(folder/'replay.json');wire=cal['stock_wire']
    require(wire['all_motion_metrics_equal'] is True and wire['all_terminal_metrics_equal'] is True and
            wire['public_cli_sha256']==plan['source_control_sha256'] and wire['exact_chunks']==cal['visual_decisions'] and
            wire['exact_offered_rows']==cal['requested_rows'] and replay['score_identical'] is True and
            replay['exact_qpos_qvel_boundaries']==cal['ticks']+1,'stock source-control and native replay')
    for i,case in enumerate(plan['cases']):
        for arm in runner.ARMS[i%3:]+runner.ARMS[:i%3]:runner.run_one('trials',case,arm)
    import summarize
    result=summarize.summarize(root)
    summarize.write(root/'results.json',result)
    ledger=trajectory_ledger(root,result)
    expected=read(root/'published_trajectory_manifest.json')
    differences=[name for name in sorted(expected['trials'].keys()|ledger.keys()) if ledger.get(name)!=expected['trials'].get(name)]
    result_env=dict(format=1,recorded_image_id=RECORDED,local_image_id=identity['image']['id'],local_stack_sha256=signature(identity['stack']),
                    protocol_sha256=PROTOCOL,local_results_sha256=hash_file(root/'results.json'),published_results_sha256=expected['results_sha256'],
                    public_source_wire_verified=True,full_panel_native_replays=result['coverage']['replays'],compared_trajectories=len(ledger),
                    mismatching_trajectories=differences,
                    status='reproduced_all_published_trajectories' if not differences else 'published_trajectories_differ')
    store(root/'reproduction_result.json',result_env)
    require(not differences,'see reproduction_result.json')


def trajectory_ledger(root,result):
    import numpy as np
    folders=['calibration/cylinder-practice19-native']+['trials/'+e['id']+'-'+e['arm'] for e in result['episodes']]
    trials={}
    for label in folders:
        folder=root/label;original=read(folder/'original.json')
        with np.load(folder/'tape.npz',allow_pickle=False) as arrays:
            archived={}
            for name in sorted(arrays.files):
                a=arrays[name]
                archived[name]=[list(a.shape),a.dtype.str,hashlib.sha256(a.tobytes()).hexdigest()]
        physics={k:original[k] for k in ('id','arm','seed','shape','state_sha256','target_sha256','native_qpos_qvel_sha256',
                 'native_reset_sha256','reset_sha256','initial_observation_sha256','initial_png_sha256','terminal','ticks','reason','motion','phase_costs','handoff_tick')}
        trials[label]=dict(tape_arrays_sha256=signature(archived),physical_record_sha256=signature(physics))
    return trials


def dispatch(root,image,checkout,out,cpu):
    plan=check_sources(root);require(not out.exists(),'choose a new, distinct output directory')
    require((root/'published_trajectory_manifest.json').is_file(),'released trajectory manifest required')
    published=read(root/'recorded_result_environment.json')
    require(published['protocol_sha256']==PROTOCOL and published['recorded_image_id']==RECORDED
            and published['runtime_sha256']==signature(read(root/'recorded_environment.json')['stack'])
            and published['physics_implementation_sha256']==hash_file(root/'implementation.json')
            and published['analysis_freeze_sha256']==hash_file(root/'analysis_freeze.json')
            and published['trajectory_manifest_sha256']==hash_file(root/'published_trajectory_manifest.json')
            and published['results_sha256']==read(root/'published_trajectory_manifest.json')['results_sha256'],'published manifest bindings')
    actual=compare_stack(root,image)
    out.mkdir(parents=True)
    for n in (*IMPLEMENTATION,'portable_recipe.py','recorded_environment.json','recorded_result_environment.json','published_trajectory_manifest.json'):
        (out/n).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(root/n,out/n)
    store(out/'local_environment.json',actual)
    snapshot=out/'snapshot';snapshot.mkdir()
    # Extract only reviewed task directories from the pinned Git tree, irrespective of checkout HEAD.
    with tempfile.TemporaryFile() as tar:
        subprocess.run(['git','-C',str(checkout),'archive',plan['task_revision']+':'+plan['task'],'environment','solution'],stdout=tar,check=True)
        tar.seek(0);subprocess.run(['tar','-xf','-','-C',str(snapshot)],stdin=tar,check=True)
    for n,h in plan['task_source_sha256'].items():require(hash_file(snapshot/n)==h,n)
    cmd=['docker','run','--rm','--read-only','--network','none','--cpuset-cpus',str(cpu),'--cpus=1','--user',f'{os.getuid()}:{os.getgid()}',
         '--tmpfs','/tmp:rw,exec','-e','PYTHONDONTWRITEBYTECODE=1','-e','MESA_SHADER_CACHE_DISABLE=true','-e','STUDY_IMAGE_ID='+actual['image']['id'],
         '--mount',f'type=bind,src={out},dst=/study','--entrypoint','/usr/bin/nice',actual['image']['id'],'-n','19','/opt/venv/bin/python3','-B','/study/portable_recipe.py','_run']
    subprocess.run(cmd,check=True)


def documentation(plan):
    return f"""# Rebuild and compare the mobile phase-cap study

The original study used Docker image `{RECORDED}`. This kit compares a locally rebuilt image against the recorded numerical stack and all public assets. Source calibration then checks the stock solver on the known public case. A final comparison covers every registered trajectory and native replay. Each local execution records its real image ID and writes into a new directory.

## Build and inspect the local image

Run from a freshly extracted kit on Linux x86-64 with Docker and host Python 3.10 or later. Select a physical CPU available to the container at launch.

```bash
git clone {SOURCE} ../mobile-benchmark
git -C ../mobile-benchmark fetch origin {plan['task_revision']}
git -C ../mobile-benchmark worktree add --detach ../mobile-frozen {plan['task_revision']}
envdir=../mobile-frozen/{plan['task']}/environment
docker build --platform linux/amd64 -f "$envdir/Dockerfile" -t mobile-phase-cap:rebuilt "$envdir"
python3 portable_recipe.py check --image mobile-phase-cap:rebuilt
```

The environment directory is the Docker build context. Its Dockerfile copies the requirements, asset fetcher and manifest, native Python simulator and mobile I/O. The build fetches the public robot, encoder and decoder. The pinned task's solution directory supplies the controller and is extracted separately from Git before launch.

## Run and verify a fresh reproduction

```bash
python3 portable_recipe.py reproduce --image mobile-phase-cap:rebuilt --checkout ../mobile-benchmark --cpu 0 --out ../mobile-reproduction-01
```

The check command reads the selected image by actual content ID and compares measured BLAS output, runtime environment, installed wheel payloads, Mesa/EGL libraries, public native source and all manifest-listed assets to `recorded_environment.json`. Passing this check establishes runtime agreement on these measurements. The synthetic source unit is included; its original entry point requires the original image ID. On a distinct image the supplemental launcher runs the frozen transform tests and independently rechecks source and runtime identity, then calls the same unmodified native calibration, recording and replay functions. It supplies Docker's actual inspected ID throughout.

The full run verifies the stock public solver at cylinder practice seed 19 before allocating the 48 study assignments. It checks 49 complete typed-array and physical trajectory signatures against the published ledger, including the calibration. The local sidecar `reproduction_result.json` records both IDs, result hashes, mismatch labels and the final comparison status. The local result JSON includes measured timings, which can differ between executions. The source CLIs retain the rendering and physics responsibilities of their registered procedures. Checksums for the contents of this kit are in `sha256.json`.
"""


def package(root):
    plan=check_sources(root)
    import summarize
    import numpy as np
    results=summarize.summarize(root)
    regenerated=(json.dumps(results,indent=2,allow_nan=False)+'\n').encode()
    require((root/'results.json').read_bytes()==regenerated,'independently serialized aggregation differs from released bytes')
    ledger=dict(protocol_sha256=PROTOCOL,results_sha256=hash_file(root/'results.json'),trials=trajectory_ledger(root,results))
    store(root/'published_trajectory_manifest.json',ledger)
    environment=read(root/'recorded_environment.json')
    sidecar=dict(format=1,recorded_image_id=RECORDED,runtime_sha256=signature(environment['stack']),protocol_sha256=PROTOCOL,
                 physics_implementation_sha256=hash_file(root/'implementation.json'),analysis_freeze_sha256=hash_file(root/'analysis_freeze.json'),
                 results_sha256=ledger['results_sha256'],trajectory_manifest_sha256=hash_file(root/'published_trajectory_manifest.json'),
                 independent_aggregation=dict(python=sys.version,numpy=np.__version__,architecture=platform.machine(),
                        libc=list(platform.libc_ver()),interpreter_sha256=hash_file(Path(sys.executable)),
                        regenerated_results_sha256=hashlib.sha256(regenerated).hexdigest(),byte_equal_to_released=True),
                 full_panel_native_replays=results['coverage']['replays'],source_control_native_replays=1)
    store(root/'recorded_result_environment.json',sidecar)
    data={n:(root/n).read_bytes() for n in (*IMPLEMENTATION,'portable_recipe.py','recorded_environment.json','recorded_result_environment.json','published_trajectory_manifest.json')}
    data['README.md']=documentation(plan).encode()
    hashes={n:hashlib.sha256(b).hexdigest() for n,b in data.items()};data['sha256.json']=encoded(hashes)
    path=root/'public-reproduction.zip'
    with tempfile.NamedTemporaryFile(dir=root,suffix='.zip',delete=False) as f:tmp=Path(f.name)
    try:
        with ZipFile(tmp,'w') as z:
            for name,blob in sorted(data.items()):z.writestr(ZipInfo(name),blob,compress_type=ZIP_DEFLATED)
        with ZipFile(tmp) as z:
            require(z.testzip() is None and set(z.namelist())==set(data) and all(z.read(n)==b for n,b in data.items()),'ZIP roundtrip')
        tmp.replace(path)
    finally:tmp.unlink(missing_ok=True)
    print(path.name,path.stat().st_size,hash_file(path))


def main():
    p=argparse.ArgumentParser(description=__doc__);subs=p.add_subparsers(dest='action',required=True)
    for name in ('capture','package','_probe','_run'):subs.add_parser(name)
    for name in ('check','reproduce'):
        sp=subs.add_parser(name);sp.add_argument('--image',required=True)
        if name=='reproduce':
            sp.add_argument('--checkout',type=Path,required=True);sp.add_argument('--cpu',type=int,required=True);sp.add_argument('--out',type=Path,required=True)
    args=p.parse_args()
    if args.action=='_probe':print(json.dumps(stack(Path('/protocol.json'))))
    elif args.action=='capture':
        check_sources(ROOT);actual=docker_probe(RECORDED,ROOT);store(ROOT/'recorded_environment.json',actual);print(actual['image']['id'],signature(actual['stack']))
    elif args.action=='check':
        check_sources(ROOT);actual=compare_stack(ROOT,args.image);print(actual['image']['id'],signature(actual['stack']))
    elif args.action=='_run':phase(Path('/study'))
    elif args.action=='package':package(ROOT)
    else:dispatch(ROOT,args.image,args.checkout.resolve(),args.out.resolve(),args.cpu)


if __name__=='__main__':
    main()
