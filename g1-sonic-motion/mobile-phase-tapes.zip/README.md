# What happens when only two body codes can change during mobile pick-and-place?

The unmodified controller completed 12/16 one-metre mobile pick-and-place starts. Limiting body changes to two coordinates per native tick produced 0/16 completions during approach and 10/16 when applied during visual manipulation. All three conditions ran from every registered start, eight box and eight cylinder.

The walking branch includes standing, gait and the wait before the public controller hands control to V4. The manipulation cap takes effect on the handoff row. Each cap selects the two largest differences between the current request and the previous applied row, breaking ties by lower coordinate index. All arms apply the full first row and pass through both fingers from their own live controller.

| Condition | Walk | Dock | V4 handoff | Contact | Lift | Strict success | Box / cylinder success |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Native | 16 | 16 | 16 | 16 | 16 | 12 | 7/8, 5/8 |
| Cap during approach | 16 | 0 | 0 | 0 | 0 | 0 | 0/8, 0/8 |
| Cap during manipulation | 16 | 16 | 16 | 16 | 15 | 10 | 5/8, 5/8 |

| Condition | Approach violations | Falls | Time limits | Mean actual s | Mean successful s | Mean failure-charged s |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Native | 0 | 0 | 4 | 17.54 | 16.06 | 17.54 |
| Cap during approach | 0 | 0 | 16 | 22.00 | — | 22.00 |
| Cap during manipulation | 0 | 0 | 6 | 18.55 | 16.48 | 18.55 |

Actual time ends at the first native terminal. Failure-charged time assigns 22 seconds to every failed start. The success mean uses only completed placements.

| Condition | Applied rows | FSQ scalar codes | Public decisions | Changed / eligible coordinates | Churn | Joint acceleration RMS (rad/s²) |
| --- | ---: | ---: | ---: | --- | ---: | ---: |
| Native | 14,035 | 898,240 | 2,811 | 29,965 / 897,216 | 3.34% | 3.191 |
| Cap during approach | 17,600 | 1,126,400 | 3,520 | 3,632 / 1,125,376 | 0.32% | 2.335 |
| Cap during manipulation | 14,841 | 949,824 | 2,973 | 28,490 / 948,800 | 3.00% | 3.050 |

| Condition | Phase | Applied rows | Capped rows | Largest number of edits/tick | Changed / eligible coordinates | Joint acceleration RMS (rad/s²) |
| --- | --- | ---: | ---: | ---: | --- | ---: |
| Native | walk | 4,000 | 0 | 28 | 13,536 / 254,976 | 5.626 |
| Native | manip | 10,035 | 0 | 30 | 16,429 / 642,240 | 1.327 |
| Cap during approach | walk | 17,600 | 17,584 | 2 | 3,632 / 1,125,376 | 2.335 |
| Cap during approach | manip | 0 | 0 | 0 | 0 / 0 | — |
| Cap during manipulation | walk | 4,000 | 0 | 28 | 13,536 / 254,976 | 5.626 |
| Cap during manipulation | manip | 10,841 | 10,841 | 2 | 14,954 / 693,824 | 1.090 |

Each executed tick sends 64 scalar FSQ codes at 50 Hz. Churn counts changed coordinates between adjacent applied rows. A transition across handoff belongs to its destination phase. Acceleration RMS pools all 29 measured body joints over 100 ms velocity differences ending in each phase. Different phase lengths and early terminals change these denominators.

| Comparison against native | Both succeeded | Native only | Capped only | Neither |
| --- | ---: | ---: | ---: | ---: |
| Cap during approach | 0 | 12 | 0 | 4 |
| Cap during manipulation | 7 | 5 | 3 | 1 |

All 32/32 native-versus-capped comparisons matched the physical reset, complete first public packet and all six initial PNG digests.

The native and manipulation-capped arms matched before intervention on 16/16 starts. This control compares both handoff ticks, all walking body/hand rows and decoder targets before handoff, measured velocities through its boundary, and each packet ID and full desired body/finger chunk up to and including the first V4 decision. When neither arm handed off, it compares the complete episode. [Per-start prefix control](walking_prefix_control.csv).

Failed starts, grouped by condition and first terminal:

- Native — time_limit: cylinder-03, cylinder-05, box-06, cylinder-07.
- Cap during approach — time_limit: box-00, cylinder-00, box-01, cylinder-01, box-02, cylinder-02, box-03, cylinder-03, box-04, cylinder-04, box-05, cylinder-05, box-06, cylinder-06, box-07, cylinder-07.
- Cap during manipulation — time_limit: cylinder-01, box-03, cylinder-03, box-04, cylinder-06, box-07.

The stock controller matched 152 public practice-seed-19 wire responses and all 760 offered rows. The calibration reproduced every published terminal and motion metric. The 48 study replays independently matched 46,476 executed body targets and finger pairs, 46,524 state and joint-velocity boundaries, all 46,524 full MuJoCo position/velocity boundaries, and every first terminal.

The [per-start ledger](per_start.csv) gives all three outcomes at every registered start. [Shape summary](method_by_shape.csv) · [Phase costs](phase_costs.csv) · [Paired endpoints](paired_outcomes.csv) · [Protocol](protocol.json) · [Reproduction instructions](REPRODUCE.md).
