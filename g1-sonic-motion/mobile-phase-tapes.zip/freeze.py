"""Freeze public starts, controller identity, interventions, resource budget and outputs."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
repo = root.parents[3] / 'benchmark_public_g1_sonic_mobile_pick_place'
revision = '62279a89db9bd4ab6d8da88b01ade40a255b7515'
slug = 'tasks/humanoid/g1_sonic_mobile_pick_place'
namespace = 'sonic-public-1m-mobile-phase-cap2-20261126-v1'
digest = lambda x: hashlib.sha256(x).hexdigest()
cases = [dict(id=f'{shape}-{i:02}', shape=shape, index=i,
              seed=int.from_bytes(hashlib.sha256(f'{namespace}|{shape}|{i}'.encode()).digest()[:8], 'big'))
         for i in range(8) for shape in ('box', 'cylinder')]
assert len({c['seed'] for c in cases} - {7, 19}) == 16
snapshot = root / 'snapshot'
files = ['solution/'+name for name in ['solve.sh','solver.py','mobile_policy.py','stand.py','v4.py','v4_actor.onnx','approach_codes.npy']]
files += ['environment/mobile_io.py', 'environment/setup/payload/practice.py','environment/public_assets.sha256']
files += [str(p.relative_to(snapshot)) for p in sorted((snapshot/'environment/sonic_sim').glob('*.py'))]
source = {}
for name in files:
    data = subprocess.check_output(['git','show',f'{revision}:{slug}/{name}'], cwd=repo)
    assert (snapshot/name).read_bytes() == data, name
    source[name] = digest(data)
plan = dict(study='Phase-specific native body coordinate caps in continuous mobile pick-and-place',version=1,
    registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), namespace=namespace,
    task_revision=revision,task=slug,course='one-metre',cases=cases, horizon=1100, tick_s=.02,
    image='sha256:120adc0ca0e2d94a4b74379bb4724f3cc51149a991662634c4a712ea6bfc452f',
    decoder_sha256='c7241a123eaa36b5d64bad19540efde93cac1ad443bd4572fd12ca99898118ed',
    task_source_sha256=source,
    study_source='Public practice LiveEpisode, MobileSession, MeasuredSession, Episode(MobilePolicy(),"v4"), fixed gait bins, V4, published SONIC V1 decoder. Full public RGB and proprio at every eligible decision. Decoder retains applied 50Hz robot history; external actor state is committed on the actual public packet ID. No warmstart or other model service.',
    comparison_source=dict(tabletop_protocol_sha256=digest((root.parent/'tabletop_token_budget/protocol.json').read_bytes()),
                           tabletop_runner_sha256=digest((root.parent/'tabletop_token_budget/runner.py').read_bytes())),
    arms={'native':'Pass all real actor body bins through unchanged.',
          'cap_walk':'Limit only body rows requested before the controller selects its visual V4 branch (includes initial standing, gait and quiet wait).',
          'cap_manip':'Limit only body rows returned by the visual V4 branch, beginning with the branch-switch decision itself.'},
    phase='Read the manipulating boolean from Episode.pending[applied_observation_id][0][0] AFTER calling existing public act, meaning all returned rows from one request share its branch. It becomes true after t>=250, measured pose bounds and five sufficiently quiet public pose-speed decisions. No native score, walk/dock/lift flag, hidden state, true object or future controls enters the decision.',
    cap='Tick zero is unrestricted. For a restricted row compare desired to the immediately preceding actually applied 64-bin vector, choose up to two largest absolute integer differences, breaking ties by lower coordinate index. Replace with current desired bins. Carry previous through every five-row decision and the controller handoff. Preserve both exact live fingers on every row. Unrestricted rows pass unchanged. Different physical histories can produce different live fingers and handoff ticks.',
    design='Full 16 matched starts x 3 arms, 8 independent public seed keys per shape. Rotate arm order within start; schedule opportunistically from frozen order under per-case locks. Include every start, failure and early terminal, no tuning, re-seeding, retries after valid failure, model changes or outcome-selected subgroups.',
    calibration='Before the first fresh reset, run cylinder public practice seed19 on the published reference image. Compare every original desired action chunk with untouched solve.sh in a separate solver process on the same full live packets, and match every native terminal metric, time and public motion statistic to the recorded public CLI result. Independently replay the full applied tape. The earlier GPU canonical_dev seed19 is a separate arithmetic runtime and supplies no training, control or acceptance targets.',
    source_control_sha256=digest((root/'calibration_source/public-cli-cylinder19.json').read_bytes()),
    reset='Require identical original native reset hashes, full first public packet and six initial native PNG hashes among all three arms per new start. Disclose any discrepancy without replacing seeds; withhold exact-paired claims for affected comparisons.',
    endpoints='Primary native strict success after ordered walk/dock/placement on all 16. Count walked, docked, controller handoff, contacted, lifted, placed, approach violation, fall and timeout. Score failure denominator intact. Report success-conditioned physical time and all-start actual/failure-charged time (22s for each failure). Paired outcomes by shape, phase and strict success for both variants against native; list all failures.',
    diagnostics='Report 50Hz applied rows and 64 scalar FSQ values per row, 10Hz public decisions, actual changed bins and within-phase rows relative to preceding applied row. At each transition attribute change to its destination phase. Report measured 29-joint acceleration RMS using displacement in velocity between t and t-5 over 0.10s, including reset and all native steps; separate pooled per-phase RMS. Fingers are separate, never capped. Complete dense rows still pass through the wire in all arms.',
    verification='Archive desired and applied body/hand rows, policy branch per decision, calibrated initial RGB hashes, full public decision IDs, actual measured dq, 29 decoder targets, hashes of state and MuJoCo qpos/qvel from reset through terminal. Fresh image-free native replay every original from codes and two untouched fingers, checking every physical boundary/target, true terminal reason/score, and independently reconstructing all registered metrics. No alternate/counterfactual practice observations in study. Baseline cross-check against stock solve.sh and public prior practice output.',
    budget='No more than three public nice19 workers, each bound to one distinct physical CPU, on released slots only, across all simultaneous official + study mobile renderers <=3. Expected ~5 to 7 min/episode and ~2h wall on three cores; 16-start study prespecified before any new physical outcomes. No downsizing after physical start. Full controls, replay and lightweight reproducibility kit.',
    gates='All 48 original plus independent replay receipts must close before statistical results; absolute verification failure is preserved transparently and no unfavorable assignment is replaced.')
out=root/'protocol.json'
with out.open('x') as f: json.dump(plan,f,indent=2,allow_nan=False);f.write('\n')
print(digest(out.read_bytes()))
