# Reproduce the mobile phase-cap diagnostic

`portable.zip` includes all 48 study tapes, the independent practice control tape, and their original/replay receipts. `recipe.zip` includes the same source, registered starts, control input, tables and per-trial receipts. Lightweight receipts are under `published_receipts/`; fresh physical runs write to `trials/` and `calibration/`. Each ZIP includes a SHA-256 inventory.

## Check the released measurements

Use Python 3.10 or later with NumPy. To validate the ZIP CRCs and member digests, run the first command below from an extracted kit, passing the path to the original ZIP. Run the second command from the complete extracted kit to reconstruct code selection, finger equality, phase counts, motion costs, and all tables from the saved tapes.

```bash
python report.py --verify-zip /path/to/portable.zip
python summarize.py
python report.py
```

## Regenerate the native trajectories

Use a fresh extraction of the lightweight recipe. The public Git checkout used for this run identified the following origin and revision. Clone into a sibling directory, extract the frozen task into the expected snapshot, then verify the source and calibration input against the registered digests.

```bash
git clone https://github.com/Zi-ang-Cao/agentic-robotics-benchmark.git ../mobile-benchmark
rev=62279a89db9bd4ab6d8da88b01ade40a255b7515
task=tasks/humanoid/g1_sonic_mobile_pick_place
git -C ../mobile-benchmark fetch origin "$rev"
mkdir -p snapshot
git -C ../mobile-benchmark archive "$rev:$task" environment solution | tar -x -C snapshot
python - <<'PY'
import json, hashlib
from pathlib import Path
p=json.loads(Path('protocol.json').read_text())
for name,h in p['task_source_sha256'].items():
    assert hashlib.sha256((Path('snapshot')/name).read_bytes()).hexdigest()==h, name
assert hashlib.sha256(Path('calibration_source/public-cli-cylinder19.json').read_bytes()).hexdigest()==p['source_control_sha256']
PY
```

The protocol and launcher pin Docker image `sha256:120adc0ca0e2d94a4b74379bb4724f3cc51149a991662634c4a712ea6bfc452f`. Run the following commands on a Linux x86-64 host with that exact image loaded. The image contains the public decoder, robot assets, physics, camera renderer and numeric runtime. The source repository includes its Dockerfile and build inputs. A locally rebuilt image can have a different Docker ID; exact launch requires the registered ID. The study bundles omit these reusable assets.

```bash
docker image inspect sha256:120adc0ca0e2d94a4b74379bb4724f3cc51149a991662634c4a712ea6bfc452f >/dev/null
CPU=0  # replace with one available physical CPU
bash run.sh "$CPU" unit
bash run.sh "$CPU" calibrate
bash run.sh "$CPU" panel
python summarize.py
python report.py
```

Each invocation uses an offline, read-only container, one CPU and nice 19. The panel launcher traverses the frozen order and skips each completed assignment after checking its receipts. Timing and compressed-file hashes can differ across fresh executions. Compare the applied rows and measured trajectory arrays, the per-episode native state/target digests, and terminal fields. The recorded public practice CLI measurement is the calibration input.
