"""Run the registered public mobile phase-cap study and a second full native replay."""
import argparse
import base64
from contextlib import ExitStack
import fcntl
import hashlib
import io
import json
import math
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

import numpy as np
from PIL import Image

ROOT = Path('/study')
SNAPSHOT = ROOT / 'snapshot'
sys.path[:0] = [str(SNAPSHOT/'environment/setup/payload'),str(SNAPSHOT/'solution'),'/opt/sonic']
import practice
from mobile_io import LiveEpisode
from mobile_policy import MobilePolicy
from solver import Episode
from sonic_sim import MobileSession
from sonic_sim.motion_cost import MeasuredSession

ASSETS = Path('/opt/sonic/assets')
PROTOCOL = 'b41dd3327101feaf02be13749cdce2ff73c7ebdc0163fbe975a5348f7ca65382'
ARMS = ('native','cap_walk','cap_manip')
SOURCE = dict(id='cylinder-practice19',shape='cylinder',seed=19)
def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(path):
    return sha(path.read_bytes())

def read(path):
    return json.loads(path.read_bytes())

def dump(path,obj):
    path.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n')

def packed(state):
    return json.dumps(state,sort_keys=True,separators=(',',':'),allow_nan=False,
                      default=lambda a:a.tolist()).encode()+b'\n'

assert digest(ROOT/'protocol.json')==PROTOCOL
PLAN=read(ROOT/'protocol.json')

def inspect():
    assert PLAN['image']==os.environ['STUDY_IMAGE_ID']
    for name,h in PLAN['task_source_sha256'].items():
        assert digest(SNAPSHOT/name)==h,name
        if name.startswith(('environment/sonic_sim/','environment/mobile_io.py','environment/public_assets.sha256')):
            assert digest(Path('/opt/sonic')/Path(name).relative_to('environment'))==h,name
    assert digest(ASSETS/'policy/model_decoder.onnx')==PLAN['decoder_sha256']
    assert digest(ROOT/'calibration_source/public-cli-cylinder19.json')==PLAN['source_control_sha256']
    implementation=read(ROOT/'implementation.json')
    for name in ('runner.py','run.sh'):
        assert digest(ROOT/name)==implementation['sha256'][name],name

def restricted(arm,manip):
    return (arm=='cap_manip' and manip) or (arm=='cap_walk' and not manip)

def transform(arm,tick,manip,desired,previous):
    if arm not in ARMS:
        raise ValueError(arm)
    wanted=np.asarray(desired,dtype=np.uint8)
    if not restricted(arm,manip):
        return wanted.copy()
    out=[]
    for i,row in enumerate(wanted):
        if tick+i==0:
            applied=row.copy()
        else:
            delta=np.abs(row.astype(np.int16)-previous.astype(np.int16))
            ids=np.argsort(-delta,kind='stable')[:2]
            applied=previous.copy()
            applied[ids]=row[ids]
        out.append(applied)
        previous=applied
    return np.asarray(out,np.uint8)

def safety_tests():
    old=np.full(64,16,np.uint8)
    rows=np.tile(old,(5,1))
    rows[0,[1,2,17,21]]=[13,13,19,19]
    rows[1]=rows[0]
    assert np.array_equal(transform('cap_manip',250,False,rows,old),rows)
    assert np.array_equal(transform('cap_walk',250,True,rows,old),rows)
    assert np.flatnonzero(transform('cap_manip',250,True,rows,old)[0]!=old).tolist()==[1,2]
    assert np.array_equal(transform('cap_manip',250,True,rows,old)[1],rows[1])
    assert np.array_equal(transform('cap_walk',0,False,rows,None)[0],rows[0])
    assert np.array_equal(transform('cap_walk',0,False,rows,None)[1],rows[1])
    assert np.array_equal(transform('native',0,False,rows,None),rows)
    rng=np.random.default_rng(20261126)
    for arm in ARMS:
        last=None
        for tick in range(0,30,5):
            manip=tick>=15
            wanted=rng.integers(0,32,(5,64),dtype=np.uint8)
            applied=transform(arm,tick,manip,wanted,last)
            for k,x in enumerate(applied):
                if last is None or not restricted(arm,manip):
                    assert np.array_equal(x,wanted[k])
                else:
                    expected=last.copy()
                    ids=sorted(range(64),key=lambda j:(-abs(int(wanted[k,j])-int(last[j])),j))[:2]
                    expected[ids]=wanted[k,ids];assert np.array_equal(expected,x)
                last=x
    print('Runtime, public asset, first-row, phase handoff, stable tie, and cap tests passed.',flush=True)

def native_bytes(sim):
    # Only the external measurement recorder/auditor reads the MuJoCo integration state.
    d=sim._scene.data
    return np.ascontiguousarray(d.qpos,dtype='<f8').tobytes()+np.ascontiguousarray(d.qvel,dtype='<f8').tobytes()

class Tape:
    def __init__(self,sim):
        self.sim=sim
        self.motion=MeasuredSession(sim)
        self.codes=[];self.hands=[];self.targets=[]
        self.dq=[sim.state['observation']['dq'].copy()]
        initial=packed(sim.state)
        self.initial=sha(initial);self.states=hashlib.sha256(initial)
        self.integration=hashlib.sha256(native_bytes(sim))
        self.native_initial=self.integration.hexdigest()
        self.target_digest=hashlib.sha256()

    def __getattr__(self,name):
        return getattr(self.sim,name)

    def step(self,token,left,right):
        state=self.motion.step(token,left,right)
        self.codes.append(np.rint(token*16+16).astype(np.uint8))
        self.hands.append([left,right])
        target=np.ascontiguousarray(self.sim.last_target,dtype='<f8')
        self.targets.append(target.copy());self.dq.append(state['observation']['dq'].copy())
        self.states.update(packed(state));self.integration.update(native_bytes(self.sim))
        self.target_digest.update(target.tobytes())
        return state

def phase_costs(codes,requested,phases,dq,arm):
    totals={}
    n=len(codes)
    for name,manip in (('walk',False),('manip',True)):
        mask=phases==manip
        rows=int(mask.sum())
        dest=mask[1:]
        differences=codes[1:].astype(np.int16)-codes[:-1].astype(np.int16)
        change=np.count_nonzero(differences[dest],axis=1)
        residual=np.abs(codes[mask].astype(np.int16)-requested[mask].astype(np.int16))
        sq=0.;samples=0
        for end in range(5,n+1):
            if mask[end-1]:
                a=(np.asarray(dq[end],np.float64)-np.asarray(dq[end-5],np.float64))/.1
                sq+=float(a@a);samples+=29
        totals[name]=dict(rows=rows,transitions=int(dest.sum()),changed_coordinates=int(change.sum()),
                          desired_body_rows_exact=int((residual==0).all(axis=1).sum()),
                          abs_native_bin_error_sum=int(residual.sum()),max_changed_coordinates=int(change.max(initial=0)),
                          restricted_rows=int(dest.sum()) if restricted(arm,manip) else 0,
                          absolute_bin_jump=int(np.abs(differences[dest]).sum()),accel_square_sum=sq,accel_samples=samples)
        if restricted(arm,manip):assert change.max(initial=0)<=2
        else:assert not residual.any()
    return totals

def source_wire(stack):
    home=Path(stack.enter_context(tempfile.TemporaryDirectory(prefix='mobile-stock-')))
    subprocess.run(['bash',str(SNAPSHOT/'solution/solve.sh')],env={**os.environ,'ALE_HOME':str(home)},check=True)
    return stack.enter_context(practice.solver(home/'submission'))

def record(case,arm,folder,source=False):
    beginning=time.monotonic()
    actor=Episode(MobilePolicy(),'v4')
    wanted=[];fingers=[];ids=[];ticks=[];modes=[]
    first_rgb=None;initial_png={}
    previous=None
    with ExitStack() as stack:
        wire=source_wire(stack) if source else None
        sim=stack.enter_context(MobileSession(case['shape']+'_to_pad_challenge',case['seed'],ASSETS))
        instrument=Tape(sim);live=LiveEpisode(instrument)
        while not sim.state['done']:
            packet=live.observe();tick=packet['tick'];key=packet['observation_id']
            assert tick==len(instrument.codes) and tick%5==0
            if tick==0:
                initial_png={f'{scale}/{k}':sha(base64.b64decode(v)) for scale in ('vision','planner_vision')
                             for k,v in packet[scale]['images'].items()}
                first_rgb=np.stack([np.asarray(Image.open(io.BytesIO(base64.b64decode(packet['vision']['images'][k])))) for k in ('hand','overview','side')])
            request={'type':'act','t':tick,'obs':packet}
            rows=actor.act(request)['rows']
            if wire is not None:
                assert practice.ask(wire,packet,sim.horizon)==rows,(case['id'],tick)
            # The public policy returns its chosen branch as the first value of its pending snapshot.
            manip=actor.pending[key][0][0]
            assert type(manip) is bool and (not modes or not modes[-1] or manip)
            assert manip==actor.policy.manipulating and len(rows)==5
            desired=np.asarray([r['codes'] for r in rows],np.uint8)
            hand=np.asarray([r['hand'] for r in rows],np.float64)
            assert desired.shape==(5,64) and np.all(desired<=31)
            applied=transform(arm,tick,manip,desired,previous)
            outgoing={'rows':[{'codes':r.tolist(),'hand':h.tolist()} for r,h in zip(applied,hand)]}
            executed=live.advance(outgoing,key)
            assert executed==5 or sim.state['done']
            previous=applied[executed-1].copy()
            wanted.append(desired);fingers.append(hand);ticks.append(tick);ids.append(key);modes.append(manip)
        terminal=sim.state
        motion=instrument.motion.action_metrics()
        codes=np.asarray(instrument.codes);hands=np.asarray(instrument.hands);n=len(codes)
        requested=np.concatenate(wanted)[:n];expected_hands=np.concatenate(fingers)[:n]
        assert np.array_equal(expected_hands,hands)
        phases=np.repeat(modes,5)[:n];dq=np.asarray(instrument.dq)
        phase=phase_costs(codes,requested,phases,dq,arm)
        assert sum(x['changed_coordinates'] for x in phase.values())==motion['changed_coordinates']
        assert sum(x['rows'] for x in phase.values())==motion['applied_rows']==terminal['tick']
        stock=None
        if source:
            ref=read(ROOT/'calibration_source/public-cli-cylinder19.json')
            assert ref['steps']==n and ref['reason']==terminal['reason'] and ref['metrics']==terminal['metrics']
            assert ref['motion']==motion,(ref['motion'],motion)
            stock=dict(exact_chunks=len(ticks),exact_offered_rows=5*len(ticks),public_cli_sha256=PLAN['source_control_sha256'],
                       all_terminal_metrics_equal=True,all_motion_metrics_equal=True)
        path=folder/'tape.npz'
        np.savez_compressed(path,codes=codes,hands=hands,requested=np.asarray(wanted),requested_hands=np.asarray(fingers),
                            requested_phase=np.asarray(modes),observation_ids=np.asarray(ids,dtype='S64'),
                            frame_ticks=np.asarray(ticks,dtype=np.int16),initial_rgb128=first_rgb,
                            decoder_targets=np.asarray(instrument.targets),measured_dq=dq)
        first_v4=next((t for t,phase_ in zip(ticks,modes) if phase_),None)
        result=dict(id=case['id'],shape=case['shape'],seed=case['seed'],arm=arm,protocol_sha256=PROTOCOL,
            implementation_sha256=digest(ROOT/'implementation.json'),task_revision=PLAN['task_revision'],
            state_sha256=instrument.states.hexdigest(),target_sha256=instrument.target_digest.hexdigest(),
            native_qpos_qvel_sha256=instrument.integration.hexdigest(),native_reset_sha256=instrument.native_initial,
            reset_sha256=instrument.initial,initial_observation_sha256=ids[0],initial_png_sha256=initial_png,
            tape_sha256=digest(path),ticks=n,reason=terminal['reason'],terminal=terminal['metrics'],motion=motion,
            visual_decisions=len(ticks),requested_rows=5*len(ticks),unexecuted_chunk_tail=5*len(ticks)-n,
            changed_coordinates=motion['changed_coordinates'],desired_body_rows_exact=int(np.all(requested==codes,axis=1).sum()),
            abs_native_bin_error_sum=int(np.abs(requested.astype(np.int16)-codes.astype(np.int16)).sum()),
            hands_match_live_policy=True,handoff_tick=first_v4,phase_costs=phase,stock_wire=stock,
            worker_affinity=sorted(os.sched_getaffinity(0)),worker_nice=os.nice(0),record_wall_seconds=time.monotonic()-beginning)
    dump(folder/'original.json',result)
    return result

def replay(folder):
    start=time.monotonic()
    original=read(folder/'original.json')
    assert digest(folder/'tape.npz')==original['tape_sha256']
    with np.load(folder/'tape.npz') as archive:
        codes,hands=archive['codes'],archive['hands']
        targets,dq=archive['decoder_targets'],archive['measured_dq']
        asked,fingers,modes=archive['requested'],archive['requested_hands'],archive['requested_phase']
        n=len(codes);last=None
        assert np.array_equal(hands,np.concatenate(fingers)[:n])
        for i in range(0,n,5):
            chunk=transform(original['arm'],i,modes[i//5],asked[i//5],last)
            executed=chunk[:min(5,n-i)]
            assert np.array_equal(executed,codes[i:i+5]);last=executed[-1]
        with MobileSession(original['shape']+'_to_pad_challenge',original['seed'],ASSETS) as live:
            state=live.state;state_sha=hashlib.sha256(packed(state))
            integ=hashlib.sha256(native_bytes(live));target_sha=hashlib.sha256()
            assert state_sha.hexdigest()==original['reset_sha256'] and integ.hexdigest()==original['native_reset_sha256']
            assert np.array_equal(dq[0],state['observation']['dq'])
            sum_a=0.;sum_t=0.
            for i,(row,hand) in enumerate(zip(codes,hands)):
                state=live.step((row.astype(np.float32)-16)/16,*hand)
                assert state['done']==(i==n-1)
                assert np.array_equal(live.last_target,targets[i]) and np.array_equal(dq[i+1],state['observation']['dq'])
                state_sha.update(packed(state));integ.update(native_bytes(live))
                target_sha.update(np.ascontiguousarray(live.last_target,dtype='<f8').tobytes())
                if i>=4:
                    acc=(np.asarray(dq[i+1],np.float64)-np.asarray(dq[i-4],np.float64))/.1
                    sum_a+=float(acc@acc)
                if i:
                    # Preserve actual decoder target dtype, as used by the official meter.
                    curr=targets[i].astype(live.last_target.dtype)
                    prior=targets[i-1].astype(live.last_target.dtype)
                    sum_t+=float(np.mean((curr-prior)**2))
            assert state['metrics']==original['terminal'] and state['reason']==original['reason']
            assert state_sha.hexdigest()==original['state_sha256'] and integ.hexdigest()==original['native_qpos_qvel_sha256']
            assert target_sha.hexdigest()==original['target_sha256']
        diff=np.diff(codes.astype(np.int16),axis=0);changed=int((diff!=0).sum());slots=(n-1)*64
        samples=max(0,n-4)*29
        derived=dict(applied_rows=n,applied_codes=64*n,simulated_s=n/50,
                     unique_code_rows=len(set(map(bytes,codes))),changed_coordinates=changed,
                     code_transition_slots=slots,absolute_bin_jump=int(np.abs(diff).sum()),
                     coordinate_change_fraction=changed/slots if slots else 0.,
                     target_step_rms_rad=math.sqrt(sum_t/max(1,n-1)),
                     joint_acceleration_samples=samples,joint_accel_square_sum=sum_a,
                     joint_accel_rms_rad_s2=math.sqrt(sum_a/max(1,samples)))
        assert derived==original['motion'],(derived,original['motion'])
    dump(folder/'replay.json',dict(original_sha256=digest(folder/'original.json'),tape_sha256=original['tape_sha256'],
          reset_and_all_states_sha256=original['state_sha256'],all_targets_sha256=original['target_sha256'],
          all_qpos_qvel_sha256=original['native_qpos_qvel_sha256'],exact_qpos_qvel_boundaries=n+1,
          exact_states=n+1,exact_29joint_targets=n,exact_finger_rows=n,exact_29joint_velocity_rows=n+1,
          score_identical=True,motion_identical=True,replay_wall_seconds=time.monotonic()-start))

def complete(folder,case,arm):
    rec=read(folder/'original.json');audit=read(folder/'replay.json')
    assert (rec['id'],rec['shape'],rec['seed'],rec['arm'])==(case['id'],case['shape'],case['seed'],arm)
    assert rec['protocol_sha256']==PROTOCOL and rec['implementation_sha256']==digest(ROOT/'implementation.json')
    assert digest(folder/'original.json')==audit['original_sha256'] and digest(folder/'tape.npz')==audit['tape_sha256']
    assert audit['score_identical'] and audit['motion_identical']

def run_one(kind,case,arm):
    parent=ROOT/kind;locks=parent/'locks';locks.mkdir(exist_ok=True,parents=True)
    name=case['id']+'-'+arm
    with (locks/(name+'.lock')).open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        dst=parent/name
        if dst.exists():
            complete(dst,case,arm)
            return
        tmp=Path(tempfile.mkdtemp(prefix=name+'.partial-',dir=parent))
        record(case,arm,tmp,source=kind=='calibration')
        replay(tmp)
        os.rename(tmp,dst)
        print('recorded and replayed',name,flush=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('phase',choices=('unit','calibrate','panel'))
    args=ap.parse_args()
    inspect()
    if args.phase=='unit':
        safety_tests()
    elif args.phase=='calibrate':
        run_one('calibration',SOURCE,'native')
    else:
        complete(ROOT/'calibration'/(SOURCE['id']+'-native'),SOURCE,'native')
        for i,case in enumerate(PLAN['cases']):
            for arm in ARMS[i%3:]+ARMS[:i%3]:
                run_one('trials',case,arm)

if __name__=='__main__':
    main()
