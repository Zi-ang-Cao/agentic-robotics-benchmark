#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 ]]; then
  echo 'usage: bash run.sh CPU_ID unit|calibrate|panel' >&2
  exit 2
fi
study=$(cd -- "$(dirname -- "$0")" && pwd)
image=sha256:120adc0ca0e2d94a4b74379bb4724f3cc51149a991662634c4a712ea6bfc452f
exec docker run --rm --network none --read-only --user "$(id -u):$(id -g)"     --cpuset-cpus "$1" --cpus 1 --tmpfs /tmp:rw,exec     -e "STUDY_IMAGE_ID=$image" -e PYTHONDONTWRITEBYTECODE=1 -e MESA_SHADER_CACHE_DISABLE=true     --mount "type=bind,src=$study,dst=/study"     --entrypoint /usr/bin/nice "$image" -n 19 /opt/venv/bin/python3 -B /study/runner.py "$2"
