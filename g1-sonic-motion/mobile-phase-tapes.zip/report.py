"""Create English results, CSV tables and checksum-verified full and lightweight mobile study kits."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
from tempfile import NamedTemporaryFile
from zipfile import ZIP_DEFLATED, ZIP_STORED, ZipFile, ZipInfo

from summarize import ARMS, CALIBRATION, ENDPOINTS, PHASES, ROOT, need, read, sha, summarize


def csv_file(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n')
        writer.writeheader();writer.writerows(rows)


def per_start(e):
    return dict(id=e['id'],shape=e['shape'],seed=str(e['seed']),arm=e['arm'],reason=e['reason'],
                **{k:int(e['terminal'][k]) for k in ENDPOINTS},controller_handoff=int(e['handoff_tick'] is not None),
                handoff_tick=e['handoff_tick'],ticks=e['ticks'],actual_s=e['ticks']/50,failure_charged_s=e['ticks']/50 if e['terminal']['success'] else 22,
                visual_decisions=e['visual_decisions'],requested_rows=e['requested_rows'],unused_tail=e['unexecuted_chunk_tail'],
                **e['motion'],desired_rows_exact=e['desired_body_rows_exact'],abs_bin_error=e['abs_native_bin_error_sum'],
                **{p+'_'+k:v for p in PHASES for k,v in e['phase_costs'][p].items()},
                state_sha256=e['state_sha256'],qpos_qvel_sha256=e['native_qpos_qvel_sha256'],targets_sha256=e['target_sha256'],tape_sha256=e['tape_sha256'])


def tables(root,r):
    csv_file(root/'per_start.csv',[per_start(e) for e in r['episodes']])
    arm_rows=[];phase_rows=[];paired_rows=[]
    for a,cohorts in r['per_arm'].items():
        for shape,m in cohorts.items():
            reasons={k:m['reasons'].get(k,0) for k in ('success','approach_violation','fall','time_limit')}
            arm_rows.append(dict(arm=a,cohort=shape,**{k:v for k,v in m.items() if k not in ('phase','reasons')},
                                 **{'terminal_'+k:v for k,v in reasons.items()}))
            for phase,v in m['phase'].items():
                phase_rows.append(dict(arm=a,cohort=shape,phase=phase,**v))
    for a,by_shape in r['paired_vs_native'].items():
        for shape,fields in by_shape.items():
            for endpoint,counts in fields.items():
                paired_rows.append(dict(comparison_arm=a,cohort=shape,endpoint=endpoint,**counts))
    csv_file(root/'method_by_shape.csv',arm_rows)
    csv_file(root/'phase_costs.csv',phase_rows)
    csv_file(root/'paired_outcomes.csv',paired_rows)
    prefixes=[]
    for row in r['walking_prefix_control']:
        first=row['first_mismatch'] or {}
        prefixes.append(dict(**{k:v for k,v in row.items() if k not in ('first_mismatch','field_mismatches')},
                             first_different_field=first.get('field'),first_different_tick=first.get('tick')))
    csv_file(root/'walking_prefix_control.csv',prefixes)


def fmt(v,places=2):
    return '—' if v is None else f'{v:.{places}f}'


def report(root,r):
    vals=[r['per_arm'][a]['all']['success'] for a in ARMS]
    lines=['# What happens when only two body codes can change during mobile pick-and-place?','',
           f'The unmodified controller completed {vals[0]}/16 one-metre mobile pick-and-place starts. Limiting body changes to two coordinates per native tick produced {vals[1]}/16 completions during approach and {vals[2]}/16 when applied during visual manipulation. All three conditions ran from every registered start, eight box and eight cylinder.','',
           'The walking branch includes standing, gait and the wait before the public controller hands control to V4. The manipulation cap takes effect on the handoff row. Each cap selects the two largest differences between the current request and the previous applied row, breaking ties by lower coordinate index. All arms apply the full first row and pass through both fingers from their own live controller.','',
           '| Condition | Walk | Dock | V4 handoff | Contact | Lift | Strict success | Box / cylinder success |',
           '| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    titles={'native':'Native','cap_walk':'Cap during approach','cap_manip':'Cap during manipulation'}
    for a in ARMS:
        g=r['per_arm'][a];m=g['all'];values=' | '.join(str(m[k]) for k in ('walked','docked','controller_handoff','contacted','lifted','success'))
        lines.append(f"| {titles[a]} | {values} | {g['box']['success']}/8, {g['cylinder']['success']}/8 |")
    lines+=['','| Condition | Approach violations | Falls | Time limits | Mean actual s | Mean successful s | Mean failure-charged s |',
            '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for a in ARMS:
        m=r['per_arm'][a]['all'];why=m['reasons']
        lines.append(f"| {titles[a]} | {why.get('approach_violation',0)} | {why.get('fall',0)} | {why.get('time_limit',0)} | {fmt(m['mean_actual_s'])} | {fmt(m['mean_success_s'])} | {fmt(m['mean_failure_charged_s'])} |")
    lines+=['','Actual time ends at the first native terminal. Failure-charged time assigns 22 seconds to every failed start. The success mean uses only completed placements.','',
            '| Condition | Applied rows | FSQ scalar codes | Public decisions | Changed / eligible coordinates | Churn | Joint acceleration RMS (rad/s²) |',
            '| --- | ---: | ---: | ---: | --- | ---: | ---: |']
    for a in ARMS:
        m=r['per_arm'][a]['all']
        lines.append(f"| {titles[a]} | {m['applied_rows']:,} | {m['fsq_scalars']:,} | {m['visual_decisions']:,} | {m['coordinate_changes']:,} / {m['eligible_coordinates']:,} | {100*m['hamming_fraction']:.2f}% | {fmt(m['rms_rad_s2'],3)} |")
    lines+=['','| Condition | Phase | Applied rows | Capped rows | Largest number of edits/tick | Changed / eligible coordinates | Joint acceleration RMS (rad/s²) |',
            '| --- | --- | ---: | ---: | ---: | --- | ---: |']
    for a in ARMS:
        for phase,m in r['per_arm'][a]['all']['phase'].items():
            lines.append(f"| {titles[a]} | {phase} | {m['rows']:,} | {m['restricted_rows']:,} | {m['max_changed_coordinates']} | {m['changed_coordinates']:,} / {64*m['transitions']:,} | {fmt(m['rms_rad_s2'],3)} |")
    lines+=['','Each executed tick sends 64 scalar FSQ codes at 50 Hz. Churn counts changed coordinates between adjacent applied rows. A transition across handoff belongs to its destination phase. Acceleration RMS pools all 29 measured body joints over 100 ms velocity differences ending in each phase. Different phase lengths and early terminals change these denominators.','',
            '| Comparison against native | Both succeeded | Native only | Capped only | Neither |',
            '| --- | ---: | ---: | ---: | ---: |']
    for a in ARMS[1:]:
        m=r['paired_vs_native'][a]['all']['success']
        lines.append(f"| {titles[a]} | {m['both']} | {m['native_only']} | {m['variant_only']} | {m['neither']} |")
    mismatches=[f"{e['id']}/{a}" for e in r['initial_matching'] for a,s in e['against_native'].items() if not s['exact_start']]
    exact=32-len(mismatches)
    lines+=['',f'All {exact}/32 native-versus-capped comparisons matched the physical reset, complete first public packet and all six initial PNG digests.' if exact==32
            else f'{exact}/32 comparisons matched the physical reset, complete first public packet and all six initial PNG digests. The paired table uses registered start IDs. Exact-input pairing is unverified for {", ".join(mismatches)}. The individual discrepancies are in results.json.',
            '']
    prefixes=r['walking_prefix_control'];failed=[p for p in prefixes if not p['exact']]
    lines+= [f"The native and manipulation-capped arms matched before intervention on {len(prefixes)-len(failed)}/16 starts. This control compares both handoff ticks, all walking body/hand rows and decoder targets before handoff, measured velocities through its boundary, and each packet ID and full desired body/finger chunk up to and including the first V4 decision. When neither arm handed off, it compares the complete episode. [Per-start prefix control](walking_prefix_control.csv).",'']
    if failed:
        for p in failed:
            diff=p['first_mismatch']
            lines.append(f"- {p['id']} first differed in `{diff['field']}` at tick {diff['tick']}.")
        lines.append('')
    lines+=['Failed starts, grouped by condition and first terminal:','']
    for a in ARMS:
        reasons={}
        for e in r['episodes']:
            if e['arm']==a and not e['terminal']['success']:
                reasons.setdefault(e['reason'],[]).append(e['id'])
        lines.append(f"- {titles[a]} — "+('; '.join(f"{reason}: {', '.join(ids)}" for reason,ids in sorted(reasons.items())) if reasons else 'all 16 succeeded')+'.')
    c=r['coverage'];cal=r['controls'];w=cal['stock_wire']
    lines+=['',f"The stock controller matched {w['exact_chunks']} public practice-seed-19 wire responses and all {w['exact_offered_rows']} offered rows. The calibration reproduced every published terminal and motion metric. The 48 study replays independently matched {c['target_rows']:,} executed body targets and finger pairs, {c['state_boundaries']:,} state and joint-velocity boundaries, all {c['qpos_qvel_boundaries']:,} full MuJoCo position/velocity boundaries, and every first terminal.",
            '', 'The [per-start ledger](per_start.csv) gives all three outcomes at every registered start. [Shape summary](method_by_shape.csv) · [Phase costs](phase_costs.csv) · [Paired endpoints](paired_outcomes.csv) · [Protocol](protocol.json) · [Reproduction instructions](REPRODUCE.md).','']
    (root/'README.md').write_text('\n'.join(lines))


def recipe(root,protocol):
    rev=protocol['task_revision'];task=protocol['task'];image=protocol['image']
    lines=['# Reproduce the mobile phase-cap diagnostic','',
           '`portable.zip` includes all 48 study tapes, the independent practice control tape, and their original/replay receipts. `recipe.zip` includes the same source, registered starts, control input, tables and per-trial receipts. Lightweight receipts are under `published_receipts/`; fresh physical runs write to `trials/` and `calibration/`. Each ZIP includes a SHA-256 inventory.','',
           '## Check the released measurements','',
           'Use Python 3.10 or later with NumPy. To validate the ZIP CRCs and member digests, run the first command below from an extracted kit, passing the path to the original ZIP. Run the second command from the complete extracted kit to reconstruct code selection, finger equality, phase counts, motion costs, and all tables from the saved tapes.','',
           '```bash','python report.py --verify-zip /path/to/portable.zip','python summarize.py','python report.py','```','',
           '## Regenerate the native trajectories','',
           'Use a fresh extraction of the lightweight recipe. The public Git checkout used for this run identified the following origin and revision. Clone into a sibling directory, extract the frozen task into the expected snapshot, then verify the source and calibration input against the registered digests.','',
           '```bash','git clone https://github.com/Zi-ang-Cao/agentic-robotics-benchmark.git ../mobile-benchmark',
           f'rev={rev}',f'task={task}',
           'git -C ../mobile-benchmark fetch origin "$rev"','mkdir -p snapshot',
           'git -C ../mobile-benchmark archive "$rev:$task" environment solution | tar -x -C snapshot',
           'python - <<\'PY\'','import json, hashlib','from pathlib import Path',"p=json.loads(Path('protocol.json').read_text())",
           "for name,h in p['task_source_sha256'].items():","    assert hashlib.sha256((Path('snapshot')/name).read_bytes()).hexdigest()==h, name",
           "assert hashlib.sha256(Path('calibration_source/public-cli-cylinder19.json').read_bytes()).hexdigest()==p['source_control_sha256']",'PY','```','',
           f'The protocol and launcher pin Docker image `{image}`. Run the following commands on a Linux x86-64 host with that exact image loaded. The image contains the public decoder, robot assets, physics, camera renderer and numeric runtime. The source repository includes its Dockerfile and build inputs. A locally rebuilt image can have a different Docker ID; exact launch requires the registered ID. The study bundles omit these reusable assets.','',
           '```bash',f'docker image inspect {image} >/dev/null','CPU=0  # replace with one available physical CPU',
           'bash run.sh "$CPU" unit','bash run.sh "$CPU" calibrate','bash run.sh "$CPU" panel','python summarize.py','python report.py','```','',
           'Each invocation uses an offline, read-only container, one CPU and nice 19. The panel launcher traverses the frozen order and skips each completed assignment after checking its receipts. Timing and compressed-file hashes can differ across fresh executions. Compare the applied rows and measured trajectory arrays, the per-episode native state/target digests, and terminal fields. The recorded public practice CLI measurement is the calibration input.','']
    (root/'REPRODUCE.md').write_text('\n'.join(lines))


BASE=('README.md','REPRODUCE.md','protocol.json','implementation.json','freeze.py','runner.py','run.sh','summarize.py','report.py',
      'results.json','method_by_shape.csv','per_start.csv','phase_costs.csv','paired_outcomes.csv','walking_prefix_control.csv','calibration_source/public-cli-cylinder19.json')


def members(root,protocol,full):
    entries={n:root/n for n in BASE}
    folders=['calibration/'+CALIBRATION['id']+'-native']+['trials/'+c['id']+'-'+a for c in protocol['cases'] for a in ARMS]
    for folder in folders:
        for n in ('original.json','replay.json','tape.npz') if full else ('original.json','replay.json'):
            path=folder+'/'+n
            entries[path if full else 'published_receipts/'+path]=root/path
    return entries


def verify_zip(path):
    with ZipFile(path) as z:
        names=z.namelist()
        need(len(names)==len(set(names)) and z.testzip() is None,'ZIP members/CRC')
        hashes=json.loads(z.read('sha256.json'))
        need(set(names)==set(hashes)|{'sha256.json'},'ZIP inventory')
        for name,h in hashes.items():
            p=Path(name);need(not p.is_absolute() and '..' not in p.parts,'unsafe ZIP name')
            with z.open(name) as f:
                digest=hashlib.sha256()
                for chunk in iter(lambda:f.read(1<<20),b''):digest.update(chunk)
            need(digest.hexdigest()==h,'ZIP checksum '+name)
    return len(names)


def archive(root,protocol,full):
    target=root/('portable.zip' if full else 'recipe.zip')
    items=members(root,protocol,full)
    with NamedTemporaryFile(dir=root,suffix='.zip',delete=False) as tmp:
        path=Path(tmp.name)
    try:
        hashes={name:sha(source) for name,source in items.items()}
        with ZipFile(path,'w',allowZip64=True) as z:
            for name,source in sorted(items.items()):
                info=ZipInfo(name);info.compress_type=ZIP_STORED if name.endswith('.npz') else ZIP_DEFLATED
                with source.open('rb') as r,z.open(info,'w') as w:shutil.copyfileobj(r,w)
            z.writestr(ZipInfo('sha256.json'),json.dumps(hashes,indent=2,sort_keys=True)+'\n')
        need(verify_zip(path)==len(items)+1,'archive membership');path.replace(target)
    finally:
        path.unlink(missing_ok=True)
    return target


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--verify-zip',type=Path)
    args=parser.parse_args()
    if args.verify_zip:
        print('Verified',verify_zip(args.verify_zip),'ZIP members.');return
    root=args.root;results=read(root/'results.json');plan=read(root/'protocol.json')
    need(results==summarize(root),'summary differs from native tape aggregation')
    tables(root,results);report(root,results);recipe(root,plan)
    for full in (False,True):
        path=archive(root,plan,full)
        print(path.name,path.stat().st_size,sha(path))


if __name__=='__main__':
    main()
