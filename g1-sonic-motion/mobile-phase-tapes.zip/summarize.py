"""Audit every registered mobile assignment and its native replay before aggregating outcomes."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
from statistics import mean
from zipfile import ZipFile

import numpy as np

ROOT = Path(__file__).resolve().parent
PROTOCOL_SHA = 'b41dd3327101feaf02be13749cdce2ff73c7ebdc0163fbe975a5348f7ca65382'
ARMS = ('native', 'cap_walk', 'cap_manip')
PHASES = ('walk', 'manip')
ENDPOINTS = ('walked', 'docked', 'contacted', 'lifted', 'success')
CALIBRATION = dict(id='cylinder-practice19', shape='cylinder', seed=19)


def need(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def ratio(n, d):
    return n / d if d else None


def close(a, b):
    return math.isclose(a, b, rel_tol=5e-13, abs_tol=1e-12)


def control_stats(codes, wanted, dq, manip, arm):
    n = len(codes)
    idx = np.arange(n)
    restricted = (idx > 0) & ((~manip & (arm == 'cap_walk')) | (manip & (arm == 'cap_manip')))
    need(np.array_equal(codes[~restricted], wanted[~restricted]), 'dense unrestricted or first row differs')
    capped = idx[restricted]
    if len(capped):
        previous = codes[capped-1].astype(np.int16)
        desired = wanted[capped].astype(np.int16)
        gaps = np.abs(desired-previous)
        order = np.argsort(-gaps, axis=1, kind='stable')[:, :2]
        np.put_along_axis(previous, order, np.take_along_axis(desired, order, axis=1), axis=1)
        need(np.array_equal(previous, codes[capped]), 'selected changes differ from top two with ascending-index ties')
    steps = np.diff(codes.astype(np.int16), axis=0, prepend=codes[:1])
    hamming = np.count_nonzero(steps, axis=1)
    residual = np.abs(codes.astype(np.int16)-wanted.astype(np.int16)).sum(axis=1)
    acceleration = (dq[5:]-dq[:-5]) / 0.1
    square = np.square(acceleration).sum(axis=1)
    result = {}
    for phase, use in (('walk', ~manip), ('manip', manip)):
        result[phase] = dict(rows=int(use.sum()), transitions=int((use & (idx>0)).sum()),
                             changed_coordinates=int(hamming[use].sum()), desired_body_rows_exact=int(((residual==0) & use).sum()),
                             abs_native_bin_error_sum=int(residual[use].sum()), max_changed_coordinates=int(hamming[use].max(initial=0)),
                             restricted_rows=int((restricted & use).sum()), absolute_bin_jump=int(np.abs(steps[use]).sum()),
                             accel_square_sum=float(square[use[4:]].sum()), accel_samples=29*int(use[4:].sum()))
    return result


def check_tape(path, case, arm, protocol_hash, implementation_hash, revision):
    a, replay = read(path/'original.json'), read(path/'replay.json')
    for k in ('id', 'shape', 'seed'):
        need(a[k] == case[k], 'original '+k)
    need((a['arm'], a['protocol_sha256'], a['implementation_sha256'], a['task_revision']) ==
         (arm, protocol_hash, implementation_hash, revision), 'trial identity')
    n=a['ticks']; f=a['visual_decisions']; m=a['motion']
    need(isinstance(n,int) and n>0 and f==(n+4)//5 and 5*f==a['requested_rows'] and 5*f-n==a['unexecuted_chunk_tail'], 'tick/decision coverage')
    need(a['tape_sha256']==replay['tape_sha256']==sha(path/'tape.npz') and sha(path/'original.json')==replay['original_sha256'], 'file binding')
    need(replay['reset_and_all_states_sha256']==a['state_sha256'] and replay['all_targets_sha256']==a['target_sha256'], 'native state/target binding')
    need(replay['all_qpos_qvel_sha256']==a['native_qpos_qvel_sha256'],'native integration-state binding')
    for k in ('exact_states','exact_29joint_velocity_rows','exact_qpos_qvel_boundaries'):
        need(replay[k]==n+1, k)
    for k in ('exact_finger_rows','exact_29joint_targets'):
        need(replay[k]==n,k)
    need(replay['score_identical'] is True and replay['motion_identical'] is True and a['hands_match_live_policy'] is True, 'native replay equality')
    need(all(type(a['terminal'][k]) is bool for k in ENDPOINTS) and a['terminal']['success']==(a['reason']=='success'), 'terminal outcome')
    with ZipFile(path/'tape.npz') as z:
        need(len(z.namelist())==len(set(z.namelist())) and z.testzip() is None, 'NPZ checksum/membership')
    with np.load(path/'tape.npz',allow_pickle=False) as z:
        c,h,dq,target=z['codes'],z['hands'],z['measured_dq'],z['decoder_targets']
        req,req_hands,phase=z['requested'],z['requested_hands'],z['requested_phase']
        for v,shape,dtype in ((c,(n,64),'u1'),(h,(n,2),'<f8'),(dq,(n+1,29),'<f8'),(target,(n,29),'<f8'),
                              (req,(f,5,64),'u1'),(req_hands,(f,5,2),'<f8'),(phase,(f,),'?')):
            need(v.shape==shape and v.dtype==np.dtype(dtype) and np.isfinite(v).all(),f'array {shape}/{dtype}')
        need(np.array_equal(z['frame_ticks'],np.arange(0,n,5)),'frame cadence')
        need(z['observation_ids'].shape==(f,) and z['observation_ids'][0].decode()==a['initial_observation_sha256'], 'first packet binding')
        need(req.max()<=31 and c.max()<=31 and req_hands.min()>=0 and req_hands.max()<=1, 'native bin/hand bounds')
        need(h.tobytes()==req_hands.reshape(-1,2)[:n].tobytes(), 'applied/live fingers')
        need(hashlib.sha256(target.tobytes()).hexdigest()==a['target_sha256'],'decoder targets')
        need(m['unique_code_rows']==len(np.unique(c,axis=0)),'unique bodies')
        # Decoder targets are stored as f64; the native meter subtracts in the original target dtype.
        target_delta=np.diff(target,axis=0)
        approximate=math.sqrt(np.mean(target_delta**2)) if len(target_delta) else 0.
        need(math.isclose(m['target_step_rms_rad'],approximate,rel_tol=1e-6,abs_tol=1e-12),'target step RMS')
        need(np.all(phase[1:]>=phase[:-1]),'nonmonotonic controller handoff')
        phases=np.repeat(phase,5)[:n]
        first=np.flatnonzero(phases)
        need(a['handoff_tick']==(int(first[0]) if len(first) else None),'controller handoff')
        ph=control_stats(c,req.reshape(-1,64)[:n],dq,phases,arm)
        first_rgb=z['initial_rgb128']
    for name,phase in ph.items():
        for k,v in phase.items():
            actual=a['phase_costs'][name][k]
            need(close(actual,v) if k=='accel_square_sum' else actual==v, name+'/'+k)
    add=lambda k:sum(row[k] for row in ph.values())
    need(m['simulated_s']==n/50 and m['applied_rows']==n and m['applied_codes']==64*n and m['code_transition_slots']==64*(n-1),'native motion accounting')
    need(m['changed_coordinates']==a['changed_coordinates']==add('changed_coordinates') and m['absolute_bin_jump']==add('absolute_bin_jump') and
         a['abs_native_bin_error_sum']==add('abs_native_bin_error_sum') and a['desired_body_rows_exact']==add('desired_body_rows_exact'),'whole-run code metrics')
    need(m['joint_acceleration_samples']==add('accel_samples')==29*max(0,n-4) and close(m['joint_accel_square_sum'],add('accel_square_sum')),'acceleration exposure')
    if n>4:
        need(close(m['joint_accel_rms_rad_s2'], math.sqrt(add('accel_square_sum')/(29*(n-4)))),'pooled acceleration')
    if n>1:
        need(close(m['coordinate_change_fraction'],add('changed_coordinates')/(64*(n-1))),'pooled churn')
    return a, replay, first_rgb


def by_phase(items,phase):
    pooled=Counter()
    for trial in items:
        pooled.update(trial['phase_costs'][phase])
    v=dict(pooled)
    v['max_changed_coordinates']=max((trial['phase_costs'][phase]['max_changed_coordinates'] for trial in items),default=0)
    v['hamming_fraction']=ratio(v['changed_coordinates'],64*v['transitions'])
    v['rms_rad_s2']=math.sqrt(v['accel_square_sum']/v['accel_samples']) if v['accel_samples'] else None
    return v


def pooled(items):
    phase={p:by_phase(items,p) for p in PHASES}
    total=lambda k:sum(row[k] for row in phase.values())
    n=total('rows');tr=total('transitions');samples=total('accel_samples')
    success=[e['ticks']/50 for e in items if e['terminal']['success']]
    return dict(starts=len(items), **{k:sum(bool(x['terminal'][k]) for x in items) for k in ENDPOINTS},
                controller_handoff=sum(x['handoff_tick'] is not None for x in items),
                reasons=dict(sorted(Counter(x['reason'] for x in items).items())),
                simulated_seconds=n/50, mean_actual_s=n/(50*len(items)), mean_success_s=mean(success) if success else None,
                mean_failure_charged_s=mean(e['ticks']/50 if e['terminal']['success'] else 22 for e in items),
                applied_rows=n,fsq_scalars=64*n,visual_decisions=sum(x['visual_decisions'] for x in items),
                requested_rows=sum(x['requested_rows'] for x in items),unexecuted_chunk_tail=sum(x['unexecuted_chunk_tail'] for x in items),
                coordinate_changes=total('changed_coordinates'),eligible_coordinates=64*tr,hamming_fraction=ratio(total('changed_coordinates'),64*tr),
                absolute_bin_jump=total('absolute_bin_jump'),desired_body_rows_exact=total('desired_body_rows_exact'),
                abs_native_bin_error_sum=total('abs_native_bin_error_sum'),accel_samples=samples,
                rms_rad_s2=math.sqrt(total('accel_square_sum')/samples) if samples else None,phase=phase)


def paired(groups,variant,endpoint):
    bucket=Counter()
    for arms in groups:
        outcome=lambda x: (x['handoff_tick'] is not None) if endpoint=='controller_handoff' else x['terminal'][endpoint]
        x,y=outcome(arms['native']),outcome(arms[variant])
        bucket[{(False,False):'neither',(True,True):'both',(True,False):'native_only',(False,True):'variant_only'}[x,y]]+=1
    return {k:bucket[k] for k in ('both','native_only','variant_only','neither')}


def prefix_isolation(root, case, arms):
    """Compare everything measurable before manipulation can first alter a native row."""
    left,right=arms['native'],arms['cap_manip']
    h1,h2=left['handoff_tick'],right['handoff_tick']
    both_walked_only=h1 is None and h2 is None
    end=max(left['ticks'],right['ticks']) if both_walked_only else min(x for x in (h1,h2) if x is not None)
    decisions=(end+4)//5 if both_walked_only else end//5+1
    differences=[]
    def mismatch(field,tick):
        differences.append(dict(field=field,tick=int(tick)))
    if h1!=h2: mismatch('handoff_tick',end)
    for name in ('reset_sha256','native_reset_sha256','initial_observation_sha256','initial_png_sha256'):
        if left[name]!=right[name]: mismatch(name,0)
    folders=[root/'trials'/(case['id']+'-'+a)/'tape.npz' for a in ('native','cap_manip')]
    with np.load(folders[0],allow_pickle=False) as x,np.load(folders[1],allow_pickle=False) as y:
        if x['initial_rgb128'].tobytes()!=y['initial_rgb128'].tobytes(): mismatch('initial_rgb128',0)
        for key,rows,stride in [('codes',end,1),('hands',end,1),('decoder_targets',end,1),('measured_dq',end+1,1),
                                *((v,decisions,5) for v in ('frame_ticks','observation_ids','requested_phase','requested','requested_hands'))]:
            a,b=x[key],y[key]
            common=min(len(a),len(b),rows)
            if a.dtype!=b.dtype or a.shape[1:]!=b.shape[1:]:
                mismatch(key,0)
                continue
            if common:
                av=np.ascontiguousarray(a[:common]).view('u1').reshape(common,-1)
                bv=np.ascontiguousarray(b[:common]).view('u1').reshape(common,-1)
                changed=np.flatnonzero(np.any(av!=bv,axis=1))
                if changed.size:
                    mismatch(key,changed[0]*stride)
                    continue
            if common<rows: mismatch(key,common*stride)
    if both_walked_only:
        for key in ('ticks','state_sha256','native_qpos_qvel_sha256','target_sha256','terminal','reason'):
            if left[key]!=right[key]: mismatch(key,min(left['ticks'],right['ticks']))
    differences.sort(key=lambda v:v['tick'])
    return dict(id=case['id'],native_handoff_tick=h1,cap_manip_handoff_tick=h2,whole_episode=both_walked_only,
                expected_applied_rows=end,expected_dq_boundaries=end+1,expected_decision_packets=decisions,
                exact=not differences,first_mismatch=next(iter(differences),None),field_mismatches=differences)


def summarize(root):
    protocol=read(root/'protocol.json'); implementation=read(root/'implementation.json')
    need(sha(root/'protocol.json')==PROTOCOL_SHA and tuple(protocol['arms'])==ARMS and protocol['horizon']==1100,'protocol identity')
    need(len(protocol['cases'])==16 and len({x['id'] for x in protocol['cases']})==16 and
         len({x['seed'] for x in protocol['cases']} - {19})==16,'frozen roster')
    for name in ('runner.py','run.sh'):
        need(implementation['sha256'][name]==sha(root/name),'frozen '+name)
    impl_hash=sha(root/'implementation.json')
    checks=(PROTOCOL_SHA,impl_hash,protocol['task_revision'])
    expected={c['id']+'-'+a for c in protocol['cases'] for a in ARMS}
    completed={p.parent.name for p in (root/'trials').glob('*/replay.json')}
    need(completed==expected,'complete 48-assignment replay roster required')
    known=CALIBRATION;cal_dir=root/'calibration'/(known['id']+'-native')
    calibration,cal_replay,_=check_tape(cal_dir,known,'native',*checks)
    stock=calibration['stock_wire'];cli_sha=sha(root/'calibration_source/public-cli-cylinder19.json')
    need(stock['exact_chunks']==calibration['visual_decisions'] and stock['exact_offered_rows']==calibration['requested_rows']
         and stock['public_cli_sha256']==cli_sha==protocol['source_control_sha256']
         and stock['all_terminal_metrics_equal'] is True and stock['all_motion_metrics_equal'] is True,'independent stock wire control')
    records=[];replays=[];matches=[];prefix=[];cohorts={s:[] for s in ('all','box','cylinder')}
    for c in protocol['cases']:
        arms={};imgs={}
        for arm in ARMS:
            archive=root/'trials'/(c['id']+'-'+arm)
            try:
                trial,replay,rgb=check_tape(archive,c,arm,*checks)
            except (KeyError,ValueError,TypeError,AssertionError) as exc:
                raise ValueError(f"{archive.name}: {exc}") from exc
            need(trial['reason'] in ('success','fall','time_limit','approach_violation') and trial['ticks']<=1100,'native terminal type/horizon')
            need(len(trial['initial_png_sha256'])==6,'six reset PNGs')
            records.append(trial);replays.append(replay);arms[arm]=trial;imgs[arm]=rgb
        for group in ('all',c['shape']):
            cohorts[group].append(arms)
        baseline=arms['native']
        pairs={}
        for arm in ARMS[1:]:
            e=arms[arm];a,b=imgs['native'],imgs[arm]
            pairs[arm]=dict(reset_identical=e['reset_sha256']==baseline['reset_sha256'] and e['native_reset_sha256']==baseline['native_reset_sha256'],
                            first_packet_identical=e['initial_observation_sha256']==baseline['initial_observation_sha256'],
                            differing_initial_pngs=sorted(k for k,h in baseline['initial_png_sha256'].items() if e['initial_png_sha256'].get(k)!=h),
                            initial_rgb128_changed_values=int(np.count_nonzero(a!=b)))
            pairs[arm]['exact_start']=all([pairs[arm]['reset_identical'],pairs[arm]['first_packet_identical'],
                                          not pairs[arm]['differing_initial_pngs'],np.array_equal(a,b)])
        matches.append(dict(id=c['id'],shape=c['shape'],against_native=pairs))
        prefix.append(prefix_isolation(root,c,arms))
    stats={a:{shape:pooled([g[a] for g in groups]) for shape,groups in cohorts.items()} for a in ARMS}
    comparisons={a:{shape:{ep:paired(groups,a,ep) for ep in (*ENDPOINTS,'controller_handoff')}
                    for shape,groups in cohorts.items()} for a in ARMS[1:]}
    return dict(protocol_sha256=PROTOCOL_SHA,implementation_sha256=impl_hash,task_revision=protocol['task_revision'],
                episodes=records,per_arm=stats,paired_vs_native=comparisons,initial_matching=matches,walking_prefix_control=prefix,
                controls=dict(public_seed=19,stock_wire=stock,original_sha256=cal_replay['original_sha256'],
                              tape_sha256=cal_replay['tape_sha256'],ticks=calibration['ticks']),
                coverage=dict(originals=len(records),replays=len(replays),applied_rows=sum(e['ticks'] for e in records),
                              state_boundaries=sum(r['exact_states'] for r in replays),
                              qpos_qvel_boundaries=sum(r['exact_qpos_qvel_boundaries'] for r in replays),
                              target_rows=sum(r['exact_29joint_targets'] for r in replays),finger_rows=sum(r['exact_finger_rows'] for r in replays),
                              replay_wall_seconds=sum(r['replay_wall_seconds'] for r in replays),
                              original_wall_seconds=sum(e['record_wall_seconds'] for e in records)))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,default=ROOT)
    args=p.parse_args()
    results=summarize(args.root)
    write(args.root/'results.json',results)
    print('Verified',results['coverage']['replays'],'panel replays and one public stock-wire control.')
