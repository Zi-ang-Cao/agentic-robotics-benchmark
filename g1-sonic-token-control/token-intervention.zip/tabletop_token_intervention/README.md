# Four integer edits to a G1 tabletop carry

Across eight prespecified box and cylinder starts, the public V4 actor produced a qualified load-bearing grasp at the scheduled intervention on 8/8. Four selected SONIC coordinates were edited for 300 ms, once in each requested world-y direction. The edited object met the registered directional-and-contact criterion on **11/16 requests**. The unchanged actor achieved strict final placement on **6/8 starts**, and the edited replays achieved it on **11/16**. Each run ended on the first public placement, fall or 15 s time limit.

![Native hand-camera snapshots and measured object paths for the first registered seed](review.png)

| Shape | Body-code pulse | Eligible grasp | Uninterrupted load | Directional pass | Paired y advantage (mm) | Paired off-axis motion (mm) | Strict placement |
|---|---|---:|---:|---:|---:|---:|---:|
| Box | Unedited | 4/4 | 4/4 | — | 0.0 | 0.0 | 3/4 |
| Box | −y | 4/4 | 4/4 | 4/4 | 59.1 | 32.4 | 3/4 |
| Box | +y | 4/4 | 2/4 | 2/4 | 51.2 | 18.3 | 3/4 |
| Cylinder | Unedited | 4/4 | 4/4 | — | 0.0 | 0.0 | 3/4 |
| Cylinder | −y | 4/4 | 4/4 | 4/4 | 51.6 | 27.9 | 3/4 |
| Cylinder | +y | 4/4 | 1/4 | 1/4 | 49.8 | 18.9 | 2/4 |

Among the 16 edited trajectories, 16 gained at least 5 mm relative to no edit; 14 moved at least 5 mm in the requested direction relative to their own cue. 9 both passed the full directional criterion and ultimately placed. The paired advantage measures a change caused by the edit. Actual motion from the cue also includes the movement V4 had already set in motion. Each CSV row includes the measured world x, y and z components. The no-edit control has no requested sign.

## Native controls and outcomes

| Condition (eight starts each) | Native time, mean (s) | Successful placement, mean (s) | Applied rows | Dense scalar codes | Scalars edited vs matched row | Adjacent-coordinate changes | Joint RMS, whole / pulse (rad/s²) | Falls / timeouts |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Unedited | 12.68 | 11.90 | 5,070 | 324,480 | 0 | 6,713/323,968 (2.1%) | 2.29 / 1.32 | 0 / 2 |
| −y pulse | 12.64 | 11.86 | 5,058 | 323,712 | 480 | 6,769/323,200 (2.1%) | 2.34 / 2.34 | 0 / 2 |
| +y pulse | 13.05 | 11.89 | 5,222 | 334,208 | 480 | 6,772/333,696 (2.0%) | 2.33 / 3.07 | 0 / 3 |

## Reproduce in Docker

Unzip the archive and run the commands inside its top-level directory. This kit includes the participant environment build sources and the task's frozen reviewer V4 graph. The Docker build fetches the public pinned SONIC decoder, Unitree model and licenses. Subsequent runs use CPU MuJoCo, ONNX Runtime and software EGL without network access. A Linux Docker host, a few gigabytes of disk space and at least 5 GiB of container memory are sufficient here. The figure-generation utility uses Matplotlib; the simulation, scoring and analysis use the dependencies already in the task image.

```bash
sha256sum -c SHA256SUMS
docker build -t sonic-tabletop-review:local task/environment
# One complete paired example (one live actor, one no-edit replay, two interventions)
OUTPUT_DIR="$PWD/fresh-box" ./run.sh --task box_to_pad_challenge --seed 1940713
docker run --rm --network none --user "$(id -u):$(id -g)" -v "$PWD:/study:ro" -v "$PWD/fresh-box:/output" --entrypoint /opt/venv/bin/python3 sonic-tabletop-review:local /study/analyze.py --results /output --task box_to_pad_challenge --seed 1940713
# Repeat the whole balanced panel
OUTPUT_DIR="$PWD/fresh-panel" ./run.sh
docker run --rm --network none --user "$(id -u):$(id -g)" -v "$PWD:/study:ro" -v "$PWD/fresh-panel:/output" --entrypoint /opt/venv/bin/python3 sonic-tabletop-review:local /study/analyze.py --results /output
```

For the standard, unedited ALE public practice protocol, install the shipped V4 through its normal reviewer entry point and run the following five-step wire check. Remove `--steps 5` to continue to the public episode terminal. A full, unmodified ALE task checkout can use the same environment and solution paths. The intervention remains a separate reviewer analysis and produces no official ALE reward.

```bash
docker run --rm --network none --user "$(id -u):$(id -g)" --cpus 2 --memory 5g -v "$PWD/task:/task:ro" -e ALE_HOME=/tmp/reviewer --entrypoint /bin/bash sonic-tabletop-review:local -c 'set -eu
bash /task/solution/solve.sh
/opt/venv/bin/python3 /task/environment/setup/payload/practice.py run --task box_to_pad --seed 1940713 --submission "$ALE_HOME/submission" --steps 5'
```

## What changes and what is measured

1. The four fixed 64-bit-compatible seeds run with both `box_to_pad_challenge` and `cylinder_to_pad_challenge`. At every five-tick decision, the live bundled V4 reads the three 128×96 RGB images from the public cameras, body proprioception and previous hand closures. Its recurrent memory and weights generate five actual rows. A first-packet check confirms that these inputs and actions match the official lossless PNG observation path. Host-only measurements of the object and scorer never enter V4.
2. Separate fresh native worlds receive the recorded nominal actions, including one no-edit control. Every available no-edit row, physical state fingerprint, 29-joint velocity, endpoint and contact record reproduces the live V4 rollout exactly. For both edit directions, all physical states, actuator controls and decoder-history fingerprints also match through the cue at tick 350 (7 s).
3. Each edited branch adds offsets to the nominal row for ticks 350 through 364, clipping each resulting bin to 0–31. For −y, coordinates 4, 18, 36 and 52 receive +4, +4, +4 and −4. For +y, coordinates 4, 10, 13 and 34 receive −4, −4, +4 and +4. The indices are zero based. Every other coordinate and every left/right finger command remain identical to the matched nominal tape at that physical tick. After the pulse, the unmodified body and finger tape resumes. If an edited branch exceeds the original placement time it holds the last nominal row and fingers. All these extra rows are identified per trial.
4. A post-intervention tape still runs the frozen SONIC decoder on the actual current robot history. The high-level V4 tape is held fixed to identify the causal effect of the changed bins; its recurrent policy is not rerun on edited images. Each native row drives ten 2 ms MuJoCo contact steps. The reviewer reads object pose and wrench-derived contact measures from this same public simulator. The public load timer resets on every unqualified substep. An uninterrupted pulse requires the timer to advance by the full 300 ms from its already-qualified cue.
5. A grasp qualifies while upright, at least 40 mm above the initial object height, with opposed hand contact, at least half the object weight carried by the hand, and at most 5% carried by other supports, continuously for at least 40 ms. The primary endpoint additionally requires at least 5 mm more motion in the requested y direction than the paired no-edit trajectory and greater axial advantage than the norm of its x/z displacement difference. All scheduled requests count, including failed eligibility, broken load and adverse drift. Stable final placement uses the public task's 250 ms supported, released, contained, slow, upright placement gate after a qualified lift.
6. Dense scalar codes equal 64 times the number of actual issued 50 Hz rows. Churn counts unequal scalar coordinates over adjacent rows in each episode. Measured joint RMS pools squared 100 ms finite differences of the 29 actual joint velocities, including reset velocity. The pulse-only RMS covers the same 15 row endpoints in every branch, using the preceding four measured velocities for the first finite differences. Simulation time counts issued rows at 20 ms; the full per-trial JSON and CSV distinguish success-conditioned and 15 s failure-censored times.

The fixed coordinate lookups were motivated by earlier native-edit and sparse-axis work. The numbers in this kit come entirely from the public challenge panel above. The runtime imports the public physical environment, the public observation code and the shipped V4 solution. The hidden grader, historical data, training environment and earlier outcome traces are absent.

[Frozen protocol](protocol.json) · [CSV for all 24 replay arms](results/episodes.csv) · [Detailed directions and denominators](results/summary.json) · [Native-camera state checks](results/showcase/receipt.json) · [Public source identities and licenses](source_manifest.json) · [Runtime, renderer and weight hashes](runtime_receipt.json) · [Practice wire result](public_practice_smoke.json)
