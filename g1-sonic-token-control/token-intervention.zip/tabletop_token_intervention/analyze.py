"""Verify single-variable intervention, native contact history, motion and endpoint budgets."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ROOT=Path(__file__).resolve().parent
SPEC=json.loads((ROOT/'protocol.json').read_text())
CUE=SPEC['cue_tick']
END=CUE+SPEC['pulse_rows']


def dump_csv(path,rows):
    with path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]),extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def aggregate(records):
    n=len(records)
    qualified=[r for r in records if r['cue_qualified']]
    relevant=[r for r in records if r['full_pulse']]
    wins=[r for r in records if r['strict_place']]
    a=sum(r['accel_samples'] for r in records)
    pulse_n=sum(r['pulse_accel_samples'] for r in records)
    changes=sum(r['changed_coordinates'] for r in records)
    eligible=sum(r['eligible_pairs'] for r in records)
    def avg(field,items=relevant):
        values=[r[field] for r in items if r[field] is not None]
        return float(np.mean(values)) if values else None
    return {'scheduled':n,'cue_qualified':len(qualified),'complete_pulse':len(relevant),'sustained':sum(r['sustained'] for r in records),
            'primary':sum(r['directional_contact_pass'] for r in records),'own_signed_5mm':sum(r['own_signed_5mm'] for r in records),
            'paired_signed_5mm':sum(r['paired_signed_5mm'] for r in records),'strict_places':len(wins),
            'primary_and_place':sum(r['directional_contact_pass'] and r['strict_place'] for r in records),
            'failure_reasons':{k:sum(r['reason']==k for r in records) for k in ('fall','time_limit')},
            'mean_paired_signed_mm':avg('paired_signed_y_mm'),'mean_own_signed_mm':avg('own_signed_y_mm'),
            'mean_paired_orthogonal_mm':avg('paired_orthogonal_mm'),'mean_paired_delta_z_mm':avg('paired_dz_mm'),
            'mean_native_time_s':avg('time_s',records),'mean_success_time_s':avg('time_s',wins),
            'mean_horizon_censored_s':float(np.mean([r['time_s'] if r['strict_place'] else SPEC['horizon_ticks']/50 for r in records])),
            'sum_control_rows':sum(r['rows'] for r in records),'applied_scalar_codes':sum(r['rows']*64 for r in records),
            'actual_edited_scalars':sum(r['edited_scalar_values'] for r in records),
            'changes':changes,'eligible_adjacent_pairs':eligible,'churn':changes/eligible if eligible else 0,
            'pulse_accel_samples':pulse_n,'pooled_300ms_joint_accel_rms_rad_s2':math.sqrt(sum(r['pulse_accel_square_sum'] for r in records)/pulse_n) if pulse_n else None,
            'joint_acceleration_samples':a,'pooled_measured_joint_accel_rms_rad_s2':math.sqrt(sum(r['sum_squared_accel'] for r in records)/a)}


def main(folder, tasks, seeds):
    all_rows=[]; controls=[]
    for task in tasks:
        for seed in seeds:
            key=f'{task}-{seed}'
            report=lambda arm:json.loads((folder/f'{key}-{arm}.json').read_text())
            live=report('live')
            with np.load(folder/f'{key}-live.npz') as l, np.load(folder/f'{key}-nominal.npz') as b:
                for field in ('codes','fingers','state_sha256','measurements','measured_dq'):
                    assert np.array_equal(l[field],b[field]),(key,field)
                rnom=report('nominal')
                assert rnom['native_terminal']==live['native_terminal']
                controls.append({'task':task,'seed':seed,'live_rows':live['applied_rows'],
                                 'replayed_nominal_state_digest':hashlib.sha256(b['state_sha256'].tobytes()).hexdigest(),
                                 'live_vs_noedit_exact_all_fields':True})
                for arm,patch in SPEC['conditions'].items():
                    with np.load(folder/f'{key}-{arm}.npz') as z:
                        q=report(arm)
                        c=z['codes'];t=len(c); hand=z['fingers']
                        nominal_idx=np.minimum(np.arange(t),len(b['codes'])-1)
                        target=b['codes'][nominal_idx]; expected=target.copy()
                        for col,offset in patch.items():
                            expected[CUE:END,int(col)]=np.clip(expected[CUE:END,int(col)].astype(int)+offset,0,31)
                        assert np.array_equal(c,expected) and np.array_equal(hand,b['fingers'][nominal_idx])
                        n=min(t,len(b['codes']),CUE)
                        assert np.array_equal(z['state_sha256'][:n+1],b['state_sha256'][:n+1])
                        shared=min(t,len(b['codes']))+1
                        diverged=np.flatnonzero(np.any(z['state_sha256'][:shared]!=b['state_sha256'][:shared],axis=1))
                        first_different_state=int(diverged[0]) if len(diverged) else None
                        assert q['applied_rows']==t and q['scalar_codes']==t*64
                        assert q['changed_coordinates']==int(np.count_nonzero(c[1:]!=c[:-1]))
                        assert q['eligible_pairs']==(t-1)*64 and q['accel_samples']==(t-4)*29
                        dq=z['measured_dq'];a=(dq[5:]-dq[:-5])/.1
                        assert np.isclose(q['rms_rad_s2'],np.sqrt(np.mean(a*a)),rtol=2e-12)
                        actual=np.count_nonzero(c!=target,axis=1)
                        assert np.all(actual<=len(patch)) and not np.any(actual[:CUE]) and not np.any(actual[END:])
                        geom=z['measurements'];bm=b['measurements']
                        enough=t>=END and len(b['codes'])>=END
                        assert enough==q['full_pulse']
                        sign=1 if arm=='y_plus' else -1 if arm=='y_minus' else 0
                        advantage=own=orth=dz=None
                        arm_delta=diff=[None]*3
                        sustain=ownpass=pairedpass=primary=False
                        pulse_a=(dq[CUE+1:END+1]-dq[CUE-4:END-4])/.1 if enough else np.empty((0,29))
                        if enough:
                            base_delta=(bm[END,1:4]-bm[CUE,1:4])*1000
                            arm_delta=(geom[END,1:4]-geom[CUE,1:4])*1000
                            diff=arm_delta-base_delta
                            advantage=float(sign*diff[1]);own=float(sign*arm_delta[1]) if sign else None;orth=float(np.hypot(diff[0],diff[2]));dz=float(diff[2])
                            eligible=(geom[CUE,7]>=.040-1e-10 and bool(geom[CUE,13]))
                            assert bool(eligible)==q['cue_qualified']
                            if eligible:
                                assert geom[CUE,11] and geom[CUE,8]>=.5*q['object_weight_n'] and geom[CUE,9]<=.05*q['object_weight_n']
                            # The native 2 ms scorer resets this timer on *any* interruption, including between 50 Hz endpoints.
                            sustain=bool(eligible and geom[END,7]+1e-9>=geom[CUE,7]+(END-CUE)/50)
                            assert sustain==q['sustained_load']
                            ownpass=own is not None and own>=5.;pairedpass=advantage>=5.
                            primary=bool(sustain and pairedpass and advantage>orth)
                        all_rows.append({'task':task,'seed':seed,'arm':arm,'prefix_rows_verified':n,'prefix_state_sha256':hashlib.sha256(z['state_sha256'][:n+1].tobytes()).hexdigest(),
                            'first_different_physical_state_tick':first_different_state,'finger_scalar_mismatches_vs_nominal':0,'cue_qualified':q['cue_qualified'],
                            'full_pulse':enough,'sustained':sustain,'own_dx_mm':arm_delta[0],'own_world_dy_mm':arm_delta[1],'own_dz_mm':arm_delta[2],
                            'paired_dx_mm':diff[0],'paired_world_dy_mm':diff[1],'own_signed_y_mm':own,'paired_signed_y_mm':advantage,
                            'paired_orthogonal_mm':orth,'paired_dz_mm':dz,'own_signed_5mm':ownpass,
                            'paired_signed_5mm':pairedpass,'directional_contact_pass':primary,
                            'strict_place':q['success'],'reason':q['reason'],'time_s':q['simulated_s'],
                            'rows':t,'edited_scalar_values':int(actual.sum()),'max_changed_vs_nominal_row':int(actual.max()),
                            'changed_coordinates':q['changed_coordinates'],'eligible_pairs':q['eligible_pairs'],
                            'churn':q['churn'],'rms_rad_s2':q['rms_rad_s2'],'accel_samples':q['accel_samples'],
                            'pulse_accel_samples':int(pulse_a.size),'pulse_accel_square_sum':float(np.square(pulse_a).sum()),
                            'pulse_accel_rms_rad_s2':float(np.sqrt(np.mean(np.square(pulse_a)))) if pulse_a.size else None,
                            'sum_squared_accel':q['sum_squared_accel'],'extended_final_nominal_rows':max(0,t-len(b['codes'])),
                            'cue_lift_hold_s':q.get('cue_lift_hold_s'),'cue_hand_load_n':q.get('cue_hand_load_n'),
                            'cue_support_load_n':q.get('cue_support_load_n'),'cue_object_elevation_m':q.get('cue_object_elevation_m'),
                            'terminal_goal_xy_error_m':q['native_terminal']['goal_error_xy_m'],'terminal_release_hold_s':q['native_terminal']['release_hold_s']})
    results={'prespecified_physical_starts':len(controls),'causal_arms':len(all_rows),'nominal_live_vs_replay':controls,
             'all_directions':aggregate([r for r in all_rows if r['arm']!='nominal']),
             'conditions':{arm:{family:aggregate([r for r in all_rows if r['arm']==arm and (family=='both' or r['task']==family)])
                                for family in ['both',*tasks]} for arm in SPEC['conditions']}}
    (folder/'summary.json').write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
    (folder/'episodes.json').write_text(json.dumps(all_rows,indent=2,allow_nan=False)+'\n')
    dump_csv(folder/'episodes.csv',all_rows)
    print(json.dumps(results['all_directions'],indent=2))


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--results',type=Path,default=ROOT/'results')
    ap.add_argument('--task',choices=SPEC['tasks']);ap.add_argument('--seed',type=int,choices=SPEC['seeds'])
    args=ap.parse_args()
    main(args.results,[args.task] if args.task else SPEC['tasks'],[args.seed] if args.seed else SPEC['seeds'])
