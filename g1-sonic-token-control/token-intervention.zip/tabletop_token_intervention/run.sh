#!/usr/bin/env bash
set -euo pipefail
here=$(cd -P -- "$(dirname -- "$0")" && pwd)
out="${OUTPUT_DIR:-$here/results}"
mkdir -p "$out"
exec docker run --rm --network none --user "$(id -u):$(id -g)" \
  --cpus "${STUDY_CPUS:-2}" --memory 5g --shm-size 256m \
  -v "$here:/study:ro" -v "$out:/output" -e PYTHONDONTWRITEBYTECODE=1 \
  -e PYTHONPATH=/opt/sonic:/study/task/solution --entrypoint /opt/venv/bin/python3 \
  "${STUDY_IMAGE:-sonic-tabletop-review:local}" /study/study.py "$@"
