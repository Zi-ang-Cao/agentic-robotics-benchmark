"""Create a compact native-camera and object-trajectory figure for the first registered seed."""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parent
R=ROOT/'results'
SEED=1940713
tasks=['box_to_pad_challenge','cylinder_to_pad_challenge']
arms=['nominal','y_minus','y_plus']
colors={'nominal':'#575a61','y_minus':'#375ca3','y_plus':'#bd551a'}
labels={'nominal':'Original V4 tape','y_minus':'−y command','y_plus':'+y command'}
fig=plt.figure(figsize=(11,8),layout='constrained')
grid=fig.add_gridspec(3,4,height_ratios=[1.,1.,1.12])
for i,task in enumerate(tasks):
    shape='Box' if i==0 else 'Cylinder'
    for j,(arm,t,title) in enumerate([('nominal',350,'Shared cue'),('y_minus',365,'−y edit'),
                                      ('nominal',365,'No edit'),('y_plus',365,'+y edit')]):
        axis=fig.add_subplot(grid[i,j])
        f=R/'showcase'/f'{task}-{SEED}-{arm}-{t}-hand.png'
        axis.imshow(Image.open(f))
        axis.set(xticks=[],yticks=[])
        if i==0:
            axis.set_title(title+(' • 0 ms' if t==350 else ' • 300 ms'),fontsize=11)
        if j==0:
            axis.set_ylabel(shape,fontsize=13)
        for sp in axis.spines.values():sp.set_visible(False)
    ax=fig.add_subplot(grid[2,2*i:2*i+2])
    for arm in arms:
        with np.load(R/f'{task}-{SEED}-{arm}.npz') as z:
            m=z['measurements']
        y=1000*(m[350:366,2]-m[350,2])
        ax.plot(np.arange(16)*20,y,color=colors[arm],lw=2,label=labels[arm])
        ax.scatter(300,y[-1],s=18,color=colors[arm])
    ax.axhline(0,color='#999',lw=.7)
    ax.set_title(shape+' movement from cue',fontsize=11)
    ax.set_xlabel('Time after cue (ms)')
    ax.set_ylabel('World y displacement (mm)')
    ax.grid(axis='y',color='#ddd',lw=.6)
    ax.spines[['top','right']].set_visible(False)
fig.legend([Line2D([],[],color=colors[a],lw=2) for a in arms],
           [labels[a] for a in arms],ncol=3,frameon=False,loc='outside lower center')
fig.savefig(ROOT/'review.png',dpi=150,bbox_inches='tight')
