"""Matched native G1 rollouts. V4 reads public images and proprioception only."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import time

import numpy as np
from PIL import Image
from types import SimpleNamespace

from sonic_io import CAMERAS, LiveEpisode, validate_action
from sonic_sim import BenchSession
from solver import observation
from v4 import V4

ROOT=Path(__file__).resolve().parent
SPEC=json.loads((ROOT/'protocol.json').read_text())
assert hashlib.sha256((ROOT/'protocol.json').read_bytes()).hexdigest()=='05f1eb6293a2b57f2589c99cf1f8c34e2a8faf464ba2df7f2f9edf91cf92e6ae'
HORIZON=SPEC['horizon_ticks']
CUE=SPEC['cue_tick']
PULSE=SPEC['pulse_rows']
ASSETS=Path('/opt/sonic/assets')
COLS=['time_s','object_x','object_y','object_z','wrist_x','wrist_y','wrist_z',
      'lift_hold_s','hand_load_z_n','support_load_z_n','pad_load_z_n','opposed',
      'hand_contact','upright','placed','release_hold_s','goal_xy_error','goal_z_error']


def digest_array(*arrays):
    h=hashlib.sha256()
    for a in arrays:
        h.update(np.ascontiguousarray(a).tobytes())
    return np.frombuffer(h.digest(),dtype=np.uint8)


def read_physics(sim,state):
    # Reviewer measurement only. The actor has no reference to this session.
    d=sim._scene.data
    m=state['metrics']
    return [state['seconds'],*d.body('object').xpos,*state['observation']['right_hand_pos'],
            *[m[k] for k in ('lift_hold_s','hand_load_z_n','support_load_z_n','pad_load_z_n','opposed',
                             'hand_contact','upright','placed','release_hold_s','goal_error_xy_m','goal_error_z_m')]]


def read_fingerprint(sim):
    d=sim._scene.data
    return digest_array(d.qpos,d.qvel,d.ctrl,sim.decoder_history())


def v4_action(actor,sim,state,last_hand,check_wire=False):
    images={camera:Image.fromarray(sim.camera(camera,128,96)) for camera in CAMERAS}
    packet=SimpleNamespace(images=images,proprio=state['observation'],last_hand=last_hand)
    if check_wire:
        # Verify direct camera data and rows against the participant's official
        # lossless PNG serialization and the task's reviewer solver preprocessor.
        wire=observation(LiveEpisode(sim).observe(),'v4')
        for cam in CAMERAS:
            assert np.array_equal(np.asarray(wire.images[cam]),np.asarray(images[cam]))
        before=actor.snapshot()
        reference=actor.act(wire)
        actor.restore(before)
    rows=actor.act(packet)
    if check_wire:
        assert rows==reference
    return validate_action({'rows':rows},sim.tick,HORIZON)


def run(task,seed,arm,out,nominal=None):
    started=time.monotonic()
    live=arm=='live'
    actor=V4() if live else None
    path=out/f'{task}-{seed}-{arm}'
    codes=[]; fingers=[]; state_hash=[]; trajectory=[]; velocities=[]
    base_tape=nominal['codes'] if not live else None
    base_hands=nominal['fingers'] if not live else None
    patch=SPEC['conditions'].get(arm,{})
    last_hand=[0.,0.]
    with BenchSession(task,seed,ASSETS,HORIZON) as sim:
        state=sim.state
        velocities.append(state['observation']['dq'])
        trajectory.append(read_physics(sim,state))
        state_hash.append(read_fingerprint(sim))
        while not state['done']:
            t=sim.tick
            if live:
                if t%5==0:
                    chunk=v4_action(actor,sim,state,last_hand,check_wire=(t==0))
                row=chunk[t%5]
                c=np.array(row['codes'],dtype=np.uint8)
                hand=row['hand']
            else:
                i=min(t,len(base_tape)-1)
                c=base_tape[i].copy()
                if CUE<=t<CUE+PULSE:
                    for idx,offset in patch.items():
                        j=int(idx)
                        c[j]=np.clip(int(c[j])+offset,0,31)
                hand=base_hands[i].tolist()
            assert c.shape==(64,) and c.dtype==np.uint8 and np.all(c<=31)
            assert len(hand)==2 and all(0<=x<=1 for x in hand)
            state=sim.step((c.astype(np.float32)-16.)/16.,*hand)
            d=sim._scene.data
            assert not np.any(d.qfrc_applied) and not np.any(d.xfrc_applied)
            codes.append(c); fingers.append(hand); last_hand=hand
            trajectory.append(read_physics(sim,state))
            velocities.append(state['observation']['dq'])
            state_hash.append(read_fingerprint(sim))
        metrics=state['metrics']
        weight=sim._scene.config.mass*9.81
    codes=np.asarray(codes)
    vel=np.asarray(velocities)
    acc=(vel[5:]-vel[:-5])/.100
    native=np.asarray(trajectory)
    change=int((codes[1:]!=codes[:-1]).sum())
    result={'task':task,'seed':seed,'arm':arm,'reason':state['reason'],'success':bool(metrics['success']),
            'applied_rows':len(codes),'scalar_codes':int(codes.size),'changed_coordinates':change,
            'eligible_pairs':64*(len(codes)-1),'churn':change/(64*(len(codes)-1)),'simulated_s':state['seconds'],
            'rms_rad_s2':float(np.sqrt(np.mean(acc**2))),'accel_samples':int(acc.size),
            'sum_squared_accel':float(np.square(acc).sum()),'object_weight_n':weight,
            'native_terminal':metrics,'cue_reached':len(codes)>=CUE,
            'cue_qualified':bool(len(codes)>=CUE and native[CUE,7]>=.04-1e-10 and native[CUE,13]),
            'full_pulse':len(codes)>=CUE+PULSE,
            'wall_s_excluding_archive_write':time.monotonic()-started}
    if result['full_pulse']:
        a,b=native[CUE],native[CUE+PULSE]
        result.update(cue_object_xyz_m=a[1:4].tolist(),end_object_xyz_m=b[1:4].tolist(),
                      displacement_xyz_mm=((b[1:4]-a[1:4])*1000).tolist(),
                      cue_lift_hold_s=a[7],end_lift_hold_s=b[7],cue_hand_load_n=a[8],cue_support_load_n=a[9],
                      cue_opposed=bool(a[11]),cue_object_elevation_m=a[3]-native[0,3],
                      sustained_load=bool(result['cue_qualified'] and b[7]>=a[7]+PULSE*.02-1e-9))
    out.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(path.with_suffix('.npz'),codes=codes,fingers=np.asarray(fingers),state_sha256=state_hash,
                        measured_dq=vel,measurements=native,columns=COLS)
    path.with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(task,seed,arm,state['reason'],len(codes),'cue_qualified',result['cue_qualified'],flush=True)
    return result


if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('--task',choices=SPEC['tasks'])
    a.add_argument('--seed',type=int,choices=SPEC['seeds'])
    a.add_argument('--out',type=Path,default=Path('/output'))
    args=a.parse_args()
    for task in ([args.task] if args.task else SPEC['tasks']):
        for seed in ([args.seed] if args.seed else SPEC['seeds']):
            run(task,seed,'live',args.out)
            with np.load(args.out/f'{task}-{seed}-live.npz') as z:
                tape={'codes':z['codes'],'fingers':z['fingers']}
            for arm in SPEC['conditions']:
                run(task,seed,arm,args.out,tape)
