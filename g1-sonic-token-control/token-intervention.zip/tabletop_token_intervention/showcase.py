"""Re-render cameras from saved action rows and verify their exact native state."""
import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image

from study import ASSETS, CUE, PULSE, SPEC, read_fingerprint
from sonic_sim import BenchSession


def main(folder):
    key=SPEC['seeds'][0]
    out=folder/'showcase'
    out.mkdir(exist_ok=True)
    proofs=[]
    for task in SPEC['tasks']:
        for arm in SPEC['conditions']:
            name=f'{task}-{key}-{arm}'
            with np.load(folder/(name+'.npz')) as trace, BenchSession(task,key,ASSETS,SPEC['horizon_ticks']) as sim:
                codes,hands=trace['codes'],trace['fingers']
                rows=min(CUE+PULSE,len(codes))
                for t in range(rows+1):
                    if t==CUE or t==rows:
                        assert np.array_equal(read_fingerprint(sim),trace['state_sha256'][t])
                        if (t==CUE and arm=='nominal') or t==rows:
                            for camera in ('hand','overview'):
                                Image.fromarray(sim.camera(camera,320,240)).save(out/f'{name}-{t}-{camera}.png')
                        proofs.append({'name':name,'tick':t,'qpos_qvel_ctrl_decoder_history_exact':True,
                                       'recorded_state_sha256':trace['state_sha256'][t].tobytes().hex()})
                    if t<rows:
                        sim.step((codes[t].astype(np.float32)-16.)/16.,*hands[t])
    (out/'receipt.json').write_text(json.dumps(proofs,indent=2)+'\n')
    print('Saved native hand and overview images; exact state matches:',len(proofs))


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--results',type=Path,default=Path('/output'))
    main(p.parse_args().results)
