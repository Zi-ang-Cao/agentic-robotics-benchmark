#!/usr/bin/env bash
set -euo pipefail
if [[ $# != 2 ]]; then
  echo "usage: bash run.sh PHYSICAL_CPU calibrate-or-panel" >&2
  exit 2
fi
cpu=$1
phase=$2
study=$(cd -- "$(dirname -- "$0")" && pwd)
known=$(cd "$study/../maintainer_review/public_seed7" && pwd)
image=sha256:c29e3b9018abb5247ddf8a56464df06563d8d6f552605f110c98465d46b91a0d
exec docker run --rm --network none --read-only --user "$(id -u):$(id -g)" --cpuset-cpus "$cpu" --cpus=1 --tmpfs /tmp:rw,exec \
    -e PYTHONDONTWRITEBYTECODE=1 -e MESA_SHADER_CACHE_DISABLE=true \
    --mount "type=bind,src=$study,dst=/study" --mount "type=bind,src=$known,dst=/known,readonly" \
    --entrypoint /usr/bin/nice "$image" -n 19 /opt/venv/bin/python3 -B /study/runner.py "$phase"
