"""Verify the full 48-assignment roster before reporting any outcomes."""
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
from statistics import mean, median
import zipfile

import numpy as np

HERE=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_bytes())
PLAN=read(HERE/'protocol.json')
assert sha(HERE/'protocol.json')=='2b3aa4d1bffaaf82bf6c0f6c1d4b28a7a501e9bea99a7f154c614dc5cdcf2242'
ARMS=list(PLAN['arms'])
assert sha(HERE/'summarize.py')==read(HERE/'implementation.json')['summarizer_sha256']


def check(case,arm):
    folder=HERE/'trials'/(case['id']+'-'+arm)
    a=read(folder/'original.json');r=read(folder/'replay.json')
    assert a['id']==case['id'] and a['shape']==case['shape'] and a['arm']==arm and a['seed']==case['seed']
    assert a['implementation_sha256']==sha(HERE/'implementation.json') and a['protocol_sha256']==sha(HERE/'protocol.json')
    assert sha(folder/'tape.npz')==r['tape_sha256']==a['tape_sha256']
    assert sha(folder/'original.json')==r['original_sha256']
    assert r['exact_states']==r['exact_29joint_velocity_rows']==a['ticks']+1
    assert r['exact_29joint_targets']==r['exact_finger_rows']==a['ticks']
    assert r['score_identical'] and r['motion_identical'] and a['hands_match_live_v4']
    assert a['visual_decisions']==math.ceil(a['ticks']/5)
    assert a['motion']['executed_fsq_scalars']==64*a['ticks']
    assert a['motion']['body_code_comparisons']==64*(a['ticks']-1)
    assert a['motion']['joint_acceleration_samples']==a['ticks']-4
    assert a['reason']=='success' if a['terminal']['placed'] else a['reason'] in ('time_limit','fall')
    return a


def pooled(items):
    places=sum(x['terminal']['placed'] for x in items);lifts=sum(x['terminal']['lifted'] for x in items)
    duration=[x['ticks']/50 for x in items]
    success=[x['ticks']/50 for x in items if x['terminal']['placed']]
    sumkey=lambda k:sum(x[k] for x in items)
    subkey=lambda k:sum(x['motion'][k] for x in items)
    ticks=sumkey('ticks');pairs=subkey('body_code_comparisons');edit=subkey('body_code_changes')
    samples=subkey('joint_acceleration_samples')
    sse=sum((x['motion']['joint_acceleration_rms_rad_s2']**2)*29*x['motion']['joint_acceleration_samples'] for x in items)
    seconds=ticks/50
    fps=sumkey('visual_decisions')/seconds
    return dict(starts=len(items),placed=places,lifted=lifts,contacted=sum(x['terminal']['contacted'] for x in items),
                missed_lift=len(items)-lifts,lifted_without_placement=lifts-places,
                reasons=dict(Counter(x['reason'] for x in items)),mean_actual_s=mean(duration),
                mean_success_s=mean(success) if success else None,median_success_s=median(success) if success else None,
                mean_failure_charged_s=mean(x['ticks']/50 if x['terminal']['placed'] else 15 for x in items),
                total_applied_seconds=seconds,applied_rows=ticks,fsq_scalars=64*ticks,
                desired_generated_rows=sumkey('requested_rows'),unexecuted_chunk_tail=sumkey('unexecuted_chunk_tail'),
                visual_decisions=sumkey('visual_decisions'),visual_decisions_per_applied_s=fps,
                body_write_opportunities=sumkey('body_update_opportunities'),
                body_write_opportunities_per_applied_s=sumkey('body_update_opportunities')/seconds,
                changed_coordinates=edit,eligible_comparisons=pairs,hamming_fraction=edit/pairs,
                mean_changed_coordinates_per_adjacent_row=edit/(pairs/64),
                changed_adjacent_rows=sumkey('changed_adjacent_rows'),unchanged_adjacent_rows=sumkey('unchanged_adjacent_rows'),
                max_changed_coordinates_after_reset=max(x['max_changed_coordinates_after_reset'] for x in items),
                desired_body_rows_exact=sumkey('desired_body_rows_exact'),
                absolute_bin_error_per_applied_coordinate=sumkey('abs_native_bin_error_sum')/(64*ticks),
                decision_rate_note='Rates calculated from physical tick sum can be fractionally above 10 Hz for a final partial five-row chunk.',
                processed_dense_native_bytes_if_one_byte_per_bin=ticks*64,
                hypothetical_body_delta_bytes=len(items)*64+(ticks-len(items))+2*edit,
                joint_acceleration_time_samples=samples,joint_acceleration_rms_rad_s2=math.sqrt(sse/(29*samples)),
                record_cpu_lane_wall_s=sumkey('record_wall_seconds'))


def contingency(items,variant,endpoint):
    table=Counter()
    for case in PLAN['cases']:
        a=items[case['id'],'native']['terminal'][endpoint];b=items[case['id'],variant]['terminal'][endpoint]
        table[{(0,0):'both_failed',(1,1):'both_succeeded',(1,0):'native_only',(0,1):'variant_only'}[bool(a),bool(b)]]+=1
    return {k:table[k] for k in ['both_failed','native_only','variant_only','both_succeeded']}


def main():
    expected={(case['id'],arm) for case in PLAN['cases'] for arm in ARMS}
    folders=list((HERE/'trials').glob('*/replay.json'))
    assert len(folders)==len(expected)==48
    cases={(c['id'],a):check(c,a) for c in PLAN['cases'] for a in ARMS}
    equality=[]
    for case in PLAN['cases']:
        group=[cases[case['id'],arm] for arm in ARMS]
        assert len({x['reset_sha256'] for x in group})==1
        # Publish discrepancies if any of the first rendered packets differ across independent native worlds.
        entry=dict(id=case['id'],identical_reset=True,identical_first_public_packet=len({x['initial_observation_sha256'] for x in group})==1)
        image_arrays=[]
        for arm in ARMS:
            with np.load(HERE/'trials'/(case['id']+'-'+arm)/'tape.npz') as data:image_arrays.append(data['initial_rgb128'])
        reference=image_arrays[0].astype(np.int16)
        entry['small_rgb_changed_values_vs_native']=[int(np.count_nonzero(im.astype(np.int16)-reference)) for im in image_arrays]
        entry['max_abs_small_rgb_difference_vs_native']=[int(np.max(np.abs(im.astype(np.int16)-reference))) for im in image_arrays]
        equality.append(entry)
    stats={arm:{selection:pooled([x for (k,a),x in cases.items() if a==arm and (selection=='all' or x['shape']==selection)])
                for selection in ('all','box','cylinder')} for arm in ARMS}
    pairs={arm:{metric:contingency(cases,arm,metric) for metric in ('lifted','placed')} for arm in ('cap2','hold5')}
    results=dict(protocol_sha256=sha(HERE/'protocol.json'),implementation_sha256=sha(HERE/'implementation.json'),
                 aggregation_scope='All 16 pairs per arm. Raw strict native outcomes. No leaderboard score.',
                 hypothetical_delta_accounting='Physical paths always reconstruct/apply exactly 64 numeric bins per native tick. Optional compact estimate uses 64 uint8 for the initial row, then one uint8 count per tick and two bytes per ID/replacement; excludes all finger, float wire, vision, protocol or transport overhead.',
                 per_arm=stats,paired_vs_native=pairs,initial_matching=equality,episodes=list(cases.values()))
    target=HERE/'results.json';target.write_text(json.dumps(results,indent=2,allow_nan=False)+'\n')
    print({arm:(r['all']['lifted'],r['all']['placed'],r['all']['mean_success_s'],r['all']['joint_acceleration_rms_rad_s2']) for arm,r in stats.items()})
    print('results_sha256',sha(target))


if __name__=='__main__':main()
