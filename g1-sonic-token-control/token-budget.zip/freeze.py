"""Register the paired public practice design before first contact with any new start."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
base = here.parents[2]
repo = base.parent / 'benchmark_public_add_sonic_token_space_control'
revision = '7e4d005aee30a97aba26433fe067f7a88c20d3f5'
slug = 'tasks/humanoid/g1_sonic_token_space_control'
sha=lambda data:hashlib.sha256(data).hexdigest()
namespace='g1-sonic-public-tabletop V4 cap2 hold5;2026-11-26;revision-one'
cases=[]
for index in range(8):
    for shape in ('box','cylinder'):
        key=f'{namespace}|{shape}|{index}'
        number=int.from_bytes(hashlib.sha256(key.encode()).digest()[:8],'big')
        cases.append(dict(id=f'{shape}-{index:02d}',shape=shape,seed=number,index=index))
assert len({x['seed'] for x in cases})==16 and all(x['seed']!=7 for x in cases)
source={}
for name in ['environment/sonic_io.py','environment/setup/payload/practice.py','environment/sonic_sim/__init__.py',
             'environment/sonic_sim/cameras.py','environment/sonic_sim/decoder.py','environment/sonic_sim/physics.py',
             'solution/solver.py','solution/v4.py','solution/v4_actor.onnx']:
    source[name]=sha(subprocess.check_output(['git','show',f'{revision}:{slug}/{name}'],cwd=repo))
protocol=dict(study='Paired public standing-tabletop native body update budgets',schema=1,
    registered_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    task_revision=revision,task=slug,image='sha256:c29e3b9018abb5247ddf8a56464df06563d8d6f552605f110c98465d46b91a0d',
    encoder='No encoder in any arm. Each arm uses the same frozen RGB V4 actor and public V1 decoder.',
    decoder_sha256='c7241a123eaa36b5d64bad19540efde93cac1ad443bd4572fd12ca99898118ed',
    task_source_sha256=source, prior_original_files={name:sha((base/name).read_bytes()) for name in (
        'verification/v4_sparse_protocol.json','verification/v4_sparse_edits.md','token_bandwidth.md')},
    parallel_locomotion_protocol_sha256=sha((base/'runs/pr_submission/token_update_study/panel.json').read_bytes()),
    prior_and_distinction='Earlier original challenge used 20 matched layouts across native coordinate caps and no start/full task graph identity in this registered ALE keyed scene. Earlier multi-rate study used a single-step proprioceptive MLP/recorded control and variable lookahead, not the live V4 visual five-row actor on keyed tabletop starts. This study uses these controls as a new keyed port and adds directly comparable causal V4 hold5, live hands, measured motion cost and actual action-rate statistics.',
    design='Complete factorial 16 matched new starts (8 per shape) × three arms. Seed changes reset the native scene; both physical task and goal independent from all formal/official sets. Distinct deterministic 64-bit public keys under a new namespace. All 48 enter denominators. Do not replace, remove, or select cases after outcomes; no tuning, stopping rule, warmstarts, pushes or retraining.',
    namespace=namespace,cases=cases,arms={
       'native':'Fresh V4 3-view RGB + measured proprio at every 5 ticks; apply all five requested body rows, one at each 50 Hz tick through first terminal.',
       'cap2':'Same live V4. At reset tick 0 transmit the full first requested native row. At each later 20 ms tick, compare its desired row with the last APPLIED body bins; apply at most two nonzero replacements by greatest absolute bin error, tie lower coordinate index. All other coordinates hold. The first-row exception is explicit and shared by every method.',
       'hold5':'Same live V4. At each camera decision t=0,5,10,… use the first of its five requested body rows at that tick and retain that row until the next camera boundary/terminal. Discard only the later desired BODY rows in the chunk.'},
    fingers='Every arm applies both unmodified V4 finger closures for that index of the live chunk at each 50 Hz tick. Hands are never capped, held, copied from a donor, or modified using privileged states. Resulting finger rows may differ between arms as their own observed trajectories diverge.',
    sensors='Use public LiveEpisode.observe() for a genuine RGB/proprio packet, including both native calibrated image scales. The unmodified reference Episode/V4 uses three 128×96 RGB pixels, prior applied fingers and 86 scalar proprio features at 10Hz with its own recurrent memory. Possession of unobserved state, contacts, future rendered targets or scheduled seed is forbidden inside the action transform. The native decoder observes measured robot proprio-history every 20ms, each tick is 10×2ms.',
    horizon=750,tick_s=.02,primary='Strict load-bearing, released stable physical placements out of all 16 starts per arm and 8 per shape; report qualified lifts, contact, falls/timeouts and paired wins/losses against native, plus matched-lift-then-placement failure counts.',
    quality='Report actual mean simulated 50Hz terminal time across every run, mean time conditioned on strict success, and all-start mean cost charging 15s for each failure. When no successes, report undefined success-conditioned mean. Report pooled 29-joint acceleration RMS ((dq_t-dq_t-5)/0.1, reset dq at t0, first t=5) and eligible 50Hz time samples; ratios always use pooled denominators.',
    bandwidth='Record all actually applied dense 64-bin native body rows and exact float64 hands, actual visual decisions, desired rows generated/offered, applied ticks, FSQ scalar count, eligible inter-row comparisons, Hamming changed values, changed-row frequency, actual body-write opportunities and init exceptions, unchanged/repeated/demand-equal rows. 10Hz visual decisions and possible 50Hz body updates are separate. Native wire remains full row in every arm. Any packed-byte estimate will be labeled hypothetical and exclude shared visual/finger overhead. No ALE reward/probe estimate.',
    tapes='Archive complete public inputs or observation commitments per 10Hz frame, all desired/applied code rows, desired/applied fingers, every measured joint velocity and 29 decoder targets. Capture reset and native state/target stream SHA; independently image-free replay every original tape from matched keyed reset, rechecking all targets/state/terminal/metrics. Before opening new cases reproduce known seed7 native control (all 554 box, 551 cylinder rows and published state/target digests). No new held state until these pass.',
    evidence='Publish all per-case outcomes plus blockwise native→variant matched placement/lift counts, two exact marginals and failure score denominators. Retain all public seeds and command hashes. No result-selected movie.',
    resource='At most two single-CPU native workers; coordinate with official standing/mobile validation. Freeze source/public task archive and each arm before opening any new reset. Failed runs are resumed only under identical program/protocol/input; existing complete records validated before any rerun.')
dest=here/'protocol.json'
data=json.dumps(protocol,indent=2,allow_nan=False)+'\n'
with dest.open('x') as f:f.write(data)
print(sha(data.encode()))
