"""Three paired public-tabletop token transforms, followed by independent native tape replay."""
import argparse
import base64
import fcntl
import hashlib
import io
import json
import math
import os
from pathlib import Path
import sys
import tempfile
import time

import numpy as np
from PIL import Image

ROOT = Path('/study')
TASK = ROOT/'snapshot'
sys.path[:0] = [str(TASK/'environment/setup/payload'),str(TASK/'solution'),'/opt/sonic']
import practice
from solver import Episode
from v4 import V4
from sonic_io import LiveEpisode
from sonic_sim import BenchSession

ASSETS = Path('/opt/sonic/assets')
EXPECTED = '2b3aa4d1bffaaf82bf6c0f6c1d4b28a7a501e9bea99a7f154c614dc5cdcf2242'
METHODS = ('native','cap2','hold5')
def sha(blob): return hashlib.sha256(blob).hexdigest()
def file_sha(path): return sha(path.read_bytes())
def packed(data):
    return json.dumps(data,sort_keys=True,separators=(',',':'),allow_nan=False,
                      default=lambda a:a.tolist()).encode()+b'\n'
assert file_sha(ROOT/'protocol.json')==EXPECTED
PLAN=json.loads((ROOT/'protocol.json').read_bytes())


def transform(mode, tick, desired, previous):
    """Only the clock, the desired native body bins and the preceding applied code enter."""
    result=[]
    for j,row in enumerate(desired):
        if mode=='hold5':
            chosen=desired[0]
        elif mode=='native' or tick+j==0:
            chosen=row
        else:
            delta=np.abs(row.astype(np.int16)-previous.astype(np.int16))
            order=np.argsort(-delta,kind='stable')[:2]
            chosen=previous.copy()
            chosen[order]=row[order]
        result.append(chosen)
        previous=chosen
    return np.asarray(result,np.uint8)


def inspect_runtime():
    for rel,expected in PLAN['task_source_sha256'].items():
        assert file_sha(TASK/rel)==expected,rel
        if rel.startswith('environment/sonic_'):
            assert file_sha(Path('/opt/sonic')/Path(rel).relative_to('environment'))==expected,rel
    assert file_sha(ASSETS/'policy/model_decoder.onnx')==PLAN['decoder_sha256']
    assert file_sha(ROOT/'runner.py')==json.loads((ROOT/'implementation.json').read_bytes())['runner_sha256']


class Tape:
    def __init__(self,native):
        self.native=native
        self.motion=practice.AppliedMotion(native)
        self.codes=[];self.hands=[];self.targets=[]
        self.dq=[native.state['observation']['dq'].copy()]
        self.initial=sha(packed(native.state))
        self.state_digest=hashlib.sha256(packed(native.state))
        self.target_digest=hashlib.sha256()

    def __getattr__(self,name): return getattr(self.native,name)

    def step(self,token,left,right):
        state=self.motion.step(token,left,right)
        self.codes.append(np.rint(token*16+16).astype(np.uint8))
        self.hands.append((left,right))
        target=np.ascontiguousarray(self.native.last_target,dtype='<f8')
        self.targets.append(target.copy())
        self.dq.append(state['observation']['dq'].copy())
        self.state_digest.update(packed(state))
        self.target_digest.update(target.tobytes())
        return state


def record(case,mode,folder):
    begin=time.monotonic()
    actor=Episode(V4(),'v4')
    wanted=[];fingers=[];packets=[];frame_ticks=[];first_rgb=None;first_image_hashes={}
    previous=None
    task=case['shape']+'_to_pad_challenge'
    with BenchSession(task,case['seed'],ASSETS,horizon=750) as native:
        observed=Tape(native)
        live=LiveEpisode(observed)
        while not native.state['done']:
            packet=live.observe()
            t=packet['tick']
            assert t==len(observed.codes) and t%5==0
            if t==0:
                raw=packet['vision']['images']
                first_rgb=np.stack([np.asarray(Image.open(io.BytesIO(base64.b64decode(raw[k])))) for k in ('hand','overview','side')])
                first_image_hashes={f'{group}/{key}':sha(base64.b64decode(val))
                                    for group in ('vision','planner_vision') for key,val in packet[group]['images'].items()}
            # The unmodified public controller receives the normal sensor packet only.
            action=actor.act({'type':'act','t':t,'obs':packet})
            rows=action['rows']
            assert len(rows)==5
            expected=np.asarray([r['codes'] for r in rows],np.uint8)
            assert expected.shape==(5,64) and np.all(expected<=31)
            hand=np.asarray([r['hand'] for r in rows],np.float64)
            assert hand.shape==(5,2) and np.isfinite(hand).all()
            codes=transform(mode,t,expected,previous)
            outgoing={'rows':[{'codes':r.tolist(),'hand':h.tolist()} for r,h in zip(codes,hand)]}
            n=live.advance(outgoing,packet['observation_id'])
            assert n==5 or native.state['done']
            previous=codes[n-1]
            packets.append(packet['observation_id'])
            frame_ticks.append(t)
            wanted.append(expected);fingers.append(hand)
        terminal=native.state
        actual=np.asarray(observed.codes)
        hands=np.asarray(observed.hands,np.float64)
        asked=np.concatenate(wanted)[:len(actual)]
        intended_hands=np.concatenate(fingers)[:len(actual)]
        assert np.array_equal(hands,intended_hands)
        metrics=observed.motion.summary()
        n=len(actual);assert n==terminal['tick']==metrics['executed_fsq_scalars']//64
        differences=actual[1:]!=actual[:-1]
        writes=differences.sum(axis=1)
        residual=np.abs(asked.astype(np.int16)-actual.astype(np.int16))
        assert np.count_nonzero(differences)==metrics['body_code_changes']
        if mode=='native':assert not np.any(residual)
        if mode=='cap2':assert np.all(writes<=2)
        if mode=='hold5':assert not np.any(writes[np.arange(1,n)%5!=0])
        assert len(packets)==math.ceil(n/5)
        opp=n if mode!='hold5' else len(packets)
        tape=folder/'tape.npz'
        np.savez_compressed(tape,codes=actual,hands=hands,requested=np.asarray(wanted),
                            requested_hands=np.asarray(fingers),observation_ids=np.asarray(packets,dtype='S64'),
                            frame_ticks=np.asarray(frame_ticks,dtype=np.int16),initial_rgb128=first_rgb,
                            decoder_targets=np.asarray(observed.targets),measured_dq=np.asarray(observed.dq))
        result=dict(id=case['id'],shape=case['shape'],seed=case['seed'],arm=mode,protocol_sha256=EXPECTED,
                    implementation_sha256=file_sha(ROOT/'implementation.json'),task_revision=PLAN['task_revision'],
                    state_sha256=observed.state_digest.hexdigest(),target_sha256=observed.target_digest.hexdigest(),
                    reset_sha256=observed.initial,initial_observation_sha256=packets[0],initial_png_sha256=first_image_hashes,
                    tape_sha256=file_sha(tape),ticks=n,reason=terminal['reason'],terminal=terminal['metrics'],
                    motion=metrics,visual_decisions=len(packets),body_update_opportunities=opp,
                    requested_rows=5*len(packets),unexecuted_chunk_tail=5*len(packets)-n,
                    unchanged_adjacent_rows=int(np.count_nonzero(writes==0)),changed_adjacent_rows=int(np.count_nonzero(writes)),
                    max_changed_coordinates_after_reset=int(writes.max(initial=0)),changed_coordinates=int(writes.sum()),
                    desired_body_rows_exact=int(np.count_nonzero(np.all(asked==actual,axis=1))),
                    abs_native_bin_error_sum=int(residual.sum()),hands_match_live_v4=True,
                    worker_affinity=sorted(os.sched_getaffinity(0)),worker_nice=os.nice(0),
                    record_wall_seconds=time.monotonic()-begin)
    (folder/'original.json').write_bytes(json.dumps(result,indent=2,allow_nan=False).encode()+b'\n')
    return result


def replay(folder):
    start=time.monotonic()
    rec=json.loads((folder/'original.json').read_bytes())
    assert file_sha(folder/'tape.npz')==rec['tape_sha256']
    with np.load(folder/'tape.npz') as archive:
        codes,hands=archive['codes'],archive['hands']
        targets,dq=archive['decoder_targets'],archive['measured_dq']
        desired=archive['requested'];fingers=archive['requested_hands']
        assert np.array_equal(hands,np.concatenate(fingers)[:len(hands)])
        previous=None
        for t in range(0,len(codes),5):
            block=transform(rec['arm'],t,desired[t//5],previous)
            expected=block[:min(5,len(codes)-t)]
            assert np.array_equal(codes[t:t+5],expected)
            previous=expected[-1]
        with BenchSession(rec['shape']+'_to_pad_challenge',rec['seed'],ASSETS,horizon=750) as sim:
            # This independent native run never instantiates a renderer or a V4 actor.
            s=sim.state;states=hashlib.sha256(packed(s));all_targets=hashlib.sha256()
            assert sha(packed(s))==rec['reset_sha256'] and np.array_equal(dq[0],s['observation']['dq'])
            for i,(row,hand) in enumerate(zip(codes,hands)):
                s=sim.step((row.astype(np.float32)-16)/16,*hand)
                assert s['done']==(i==len(codes)-1)
                assert np.array_equal(sim.last_target,targets[i]) and np.array_equal(dq[i+1],s['observation']['dq'])
                states.update(packed(s));all_targets.update(np.ascontiguousarray(sim.last_target,dtype='<f8').tobytes())
            assert s['reason']==rec['reason'] and s['metrics']==rec['terminal']
            assert states.hexdigest()==rec['state_sha256'] and all_targets.hexdigest()==rec['target_sha256']
        m=rec['motion']
        assert m['simulated_seconds']==len(codes)/50 and m['executed_fsq_scalars']==64*len(codes)
        assert m['body_code_changes']==int(np.count_nonzero(codes[1:]!=codes[:-1]))
        samples=len(dq)-5
        square_sum=0.0
        for tick in range(5,len(dq)):
            acceleration=(dq[tick]-dq[tick-5])/0.1
            # Match the public scalar accumulator and the order of the native velocity samples.
            square_sum+=float(np.sum(acceleration**2))
        assert m['joint_acceleration_samples']==samples
        assert math.sqrt(square_sum/(29*samples))==m['joint_acceleration_rms_rad_s2']
    evidence=dict(original_sha256=file_sha(folder/'original.json'),tape_sha256=rec['tape_sha256'],
                  reset_and_all_states_sha256=rec['state_sha256'],all_targets_sha256=rec['target_sha256'],
                  exact_states=len(codes)+1,exact_29joint_targets=len(codes),exact_finger_rows=len(codes),
                  exact_29joint_velocity_rows=len(codes)+1,score_identical=True,motion_identical=True,
                  replay_wall_seconds=time.monotonic()-start)
    (folder/'replay.json').write_text(json.dumps(evidence,indent=2)+'\n')
    return rec


def roster():
    # Rotate arm order across cases to balance worker/time ordering.
    for i,case in enumerate(PLAN['cases']):
        for mode in METHODS[i%3:]+METHODS[:i%3]:yield case,mode


def run_one(parent,case,mode):
    parent.mkdir(exist_ok=True,parents=True)
    name=case['id']+'-'+mode
    (parent/'locks').mkdir(exist_ok=True)
    with (parent/'locks'/(name+'.lock')).open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:return
        final=parent/name
        if final.exists():
            receipt=json.loads((final/'replay.json').read_bytes())
            data=json.loads((final/'original.json').read_bytes())
            assert (data['id'],data['arm'],data['seed'],data['protocol_sha256'],data['implementation_sha256'])==(case['id'],mode,case['seed'],EXPECTED,file_sha(ROOT/'implementation.json'))
            assert file_sha(final/'original.json')==receipt['original_sha256'] and file_sha(final/'tape.npz')==receipt['tape_sha256']
            return
        tmp=Path(tempfile.mkdtemp(prefix=name+'.partial-',dir=parent))
        rec=record(case,mode,tmp)
        replay(tmp)
        if case['seed']==7:
            original=PLAN['task_source_sha256']['solution/v4_actor.onnx']
            assert original=='2f4ada4c14f540ee1f99b0e875aa63ade0adbb87d63d710d5b15e4e8300d1c55'
            historical=json.loads((Path('/known')/case['shape']/'v4/receipt.json').read_bytes())
            assert historical['reset_through_terminal_state_sha256']==rec['state_sha256']
            assert historical['body_target29_sha256']==rec['target_sha256'] and historical['metrics']==rec['terminal']
            with np.load(Path('/known')/case['shape']/'v4/controls.npz') as old,np.load(tmp/'tape.npz') as new:
                assert np.array_equal(old['codes'],new['codes']) and np.array_equal(old['hand'],new['hands'])
        os.rename(tmp,final)
        print('recorded and replayed',name,flush=True)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('phase',choices=('calibrate','panel'))
    args=ap.parse_args()
    inspect_runtime()
    if args.phase=='calibrate':
        for shape in ('box','cylinder'):run_one(ROOT/'calibration',dict(id=shape+'-practice7',shape=shape,seed=7),'native')
    else:
        for shape in ('box','cylinder'):
            case=dict(id=shape+'-practice7',shape=shape,seed=7)
            d=ROOT/'calibration'/(case['id']+'-native')
            assert d.is_dir() and (d/'replay.json').is_file()
            run_one(ROOT/'calibration',case,'native') # validate the already-complete checksums
        for case,mode in roster():run_one(ROOT/'trials',case,mode)


if __name__=='__main__':main()
