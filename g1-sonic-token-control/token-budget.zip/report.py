"""Write human-readable tables and a portable archive after the paired native audit."""
import csv
import hashlib
import json
from pathlib import Path
from statistics import mean
from zipfile import ZipFile, ZIP_DEFLATED

ROOT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def compare_counts(counts):
    return f"{counts['native_only']} native-only, {counts['variant_only']} variant-only"


def write_report():
    results=json.loads((ROOT/'results.json').read_bytes())
    protocol=json.loads((ROOT/'protocol.json').read_bytes())
    methods={'native':'Native V4','cap2':'At most 2 body-coordinate changes/tick','hold5':'Hold the first body row for 5 ticks'}
    rows=[]
    for arm,title in methods.items():
        for shape,metrics in results['per_arm'][arm].items():
            rows.append(dict(arm=arm,cohort=shape,**metrics))
    csv_path=ROOT/'method_by_shape.csv'
    with csv_path.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    trials=ROOT/'per_start.csv'
    fields=['id','shape','seed','arm','reason','contacted','lifted','placed','native_rows','time_s','charged_s',
            'visual_decisions','body_write_opportunities','scalar_codes','changed_coordinates','hamming_fraction',
            'rms_joint_acceleration_rad_s2','exact_desired_rows','unexecuted_tail_rows','control_tape_sha256']
    with trials.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader()
        for e in results['episodes']:
            m=e['motion'];t=e['terminal'];writer.writerow(dict(id=e['id'],shape=e['shape'],seed=e['seed'],arm=e['arm'],
                reason=e['reason'],contacted=t['contacted'],lifted=t['lifted'],placed=t['placed'],native_rows=e['ticks'],
                time_s=m['simulated_seconds'],charged_s=m['simulated_seconds'] if t['placed'] else 15.0,
                visual_decisions=e['visual_decisions'],body_write_opportunities=e['body_update_opportunities'],
                scalar_codes=m['executed_fsq_scalars'],changed_coordinates=m['body_code_changes'],
                hamming_fraction=m['body_code_churn_fraction'],rms_joint_acceleration_rad_s2=m['joint_acceleration_rms_rad_s2'],
                exact_desired_rows=e['desired_body_rows_exact'],unexecuted_tail_rows=e['unexecuted_chunk_tail'],control_tape_sha256=e['tape_sha256']))
    lines=['# Do stricter body-token updates change precision placement?', '',
           'A frozen visual V4 controller received the same public sensor interface in three runs from each of 16 fresh native starts. At every camera update (10 Hz) it predicted five 64-bin body rows and five independent pairs of finger commands. The decoder and grippers consumed one row every 20 ms. All three conditions passed every requested finger row through unchanged from that condition’s own live actor. The native decoder retained measured robot feedback in every condition.','',
           '| Body output rule | Qualified lifts | Strict placements | Box / cylinder placements | Mean actual time | Mean time on success | Mean failure-charged time |',
           '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
    for arm,title in methods.items():
        group=results['per_arm'][arm];q=group['all']
        success=q['mean_success_s']
        value='—' if success is None else f'{success:.2f} s'
        lines.append(f"| {title} | {q['lifted']}/16 | {q['placed']}/16 | {group['box']['placed']}/8, {group['cylinder']['placed']}/8 | {q['mean_actual_s']:.2f} s | {value} | {q['mean_failure_charged_s']:.2f} s |")
    lines.extend(['','| Body output rule | Executed rows | FSQ scalars | Visual decisions | Body write opportunities | Changed coordinates | Adjacent-bin change rate | Joint accel. RMS |',
                  '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |'])
    for arm,title in methods.items():
        q=results['per_arm'][arm]['all']
        lines.append(f"| {title} | {q['applied_rows']:,} | {q['fsq_scalars']:,} | {q['visual_decisions']:,} | {q['body_write_opportunities']:,} | {q['changed_coordinates']:,} | {100*q['hamming_fraction']:.3f}% | {q['joint_acceleration_rms_rad_s2']:.3f} rad/s² |")
    lines.extend(['','The cap ranks absolute bin error against the last body row actually applied and breaks ties by lower coordinate index. Every arm writes the complete first body row at reset. The hold keeps the first body row of each camera decision for up to 100 ms. All of the native dense rows remain available in the archives. Those 64 scalar codes per applied row are distinct from the count of coordinates whose values changed.',''])
    for arm,title in list(methods.items())[1:]:
        c=results['paired_vs_native'][arm]
        lines.append(f"- {title} produced {compare_counts(c['placed'])} placements on matched starts. Qualified lifts were {compare_counts(c['lifted'])}.")
    matches=results['initial_matching']
    original_ticks=sum(e['ticks'] for e in results['episodes'])
    lines.extend(['',f"All 48 physical tapes were replayed independently without policy inference or rendering. Exact matches covered {original_ticks:,} applied body targets, finger pairs and measured velocities, {original_ticks+48:,} full native states including reset, and all terminal scores. Every paired physical reset was identical. Complete initial public packets were identical on {sum(e['identical_first_public_packet'] for e in matches)}/16 three-way comparisons. Both original public practice-seed tapes also reproduced all 1,105 archived body targets, hand commands and native state trajectories.",
                  '', 'Each trial ran until strict placement, physical fall or 15 simulated seconds. The success-only column excludes failures. The failure-charged column assigns each failed start the full 15 seconds. The adjacent-bin change rate pools all 64 comparisons between neighboring applied rows within an episode. Acceleration pools 29 measured joint velocities across 100 ms differences from tick 5 onward. The finite study describes these 16 layouts and this controller.',
                  '', 'The [complete per-start ledger](per_start.csv) covers every outcome and control hash. The [aggregate table](method_by_shape.csv) includes shape-specific costs and outcome denominators. The [protocol](protocol.json) registers the 64-bit starts and the published tests before rollout. [Raw measurements](results.json).'])
    lines.extend(['','## Reproduction','',
                  'Use the public tabletop task source at the exact revision in the protocol. Populate `snapshot/` from its environment and solution directories, retaining their names. Build the public task Docker image, or use the exact local image ID recorded in the protocol. The checksum ledger binds the simulator, V4 actor, decoder and both original practice tapes. The included `run.sh` mounts the two published controls from `../maintainer_review/public_seed7`; this directory can point to the portable archive’s `known/` folder. In an empty results directory, run `bash run.sh CPU calibrate`, then `bash run.sh CPU panel` with one or two separate available CPU IDs. Run `python summarize.py` after every paired tape has an independent replay receipt.'])
    lines.extend(['','During source calibration, a vectorized independent recomputation of the seed-7 box acceleration gave 2.4244210149176575 rad/s² versus the registered per-row accumulator value of 2.4244210149176557. All original state and target hashes matched. Before opening the first new start, the verifier was changed to use the registered per-row operation and ordered scalar addition. The methods and cases remained as registered. The original source-only attempt and both verifier identities are retained.'])
    (ROOT/'README.md').write_text('\n'.join(lines)+'\n')
    release=ROOT/'portable.zip'
    entries=[(f,ROOT/f) for f in ('README.md','protocol.json','implementation.json','freeze.py','run.sh','runner.py','summarize.py','report.py','results.json','method_by_shape.csv','per_start.csv')]
    for parent in ('calibration','trials'):
        for child in sorted((ROOT/parent).glob('*')):
            if child.is_dir() and (child/'replay.json').is_file():
                for n in ('original.json','tape.npz','replay.json'):
                    f=child/n;entries.append((str(f.relative_to(ROOT)),f))
    for shape in ('box','cylinder'):
        for name in ('controls.npz','receipt.json'):
            f=ROOT.parent/'maintainer_review/public_seed7'/shape/'v4'/name
            entries.append((f'known/{shape}/v4/{name}',f))
    assert len(entries)==11+(48+2)*3+4
    evidence=ROOT/'calibration_attempt1_source'
    entries.extend((f'calibration_attempt1_source/{f.name}',f) for f in sorted(evidence.glob('*')) if f.is_file())
    partials=sorted((ROOT/'calibration').glob('box-practice7-native.partial-*'))
    for folder in partials:
        for name in ('original.json','tape.npz'):
            f=folder/name
            if f.exists():entries.append((f'calibration_attempt1_source/{folder.name}/{name}',f))
    checksums={n:sha(f) for n,f in entries}
    with ZipFile(release,'w',ZIP_DEFLATED) as store:
        for n,f in entries:store.write(f,n)
        store.writestr('sha256.json',json.dumps(checksums,indent=2)+'\n')
    with ZipFile(release) as store:
        assert store.testzip() is None and all(hashlib.sha256(store.read(n)).hexdigest()==h for n,h in checksums.items())
    print(release.stat().st_size,sha(release),sha(ROOT/'results.json'))


if __name__=='__main__':write_report()
