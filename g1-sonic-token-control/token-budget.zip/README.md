# Do stricter body-token updates change precision placement?

A frozen visual V4 controller received the same public sensor interface in three runs from each of 16 fresh native starts. At every camera update (10 Hz) it predicted five 64-bin body rows and five independent pairs of finger commands. The decoder and grippers consumed one row every 20 ms. All three conditions passed every requested finger row through unchanged from that condition’s own live actor. The native decoder retained measured robot feedback in every condition.

| Body output rule | Qualified lifts | Strict placements | Box / cylinder placements | Mean actual time | Mean time on success | Mean failure-charged time |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Native V4 | 16/16 | 15/16 | 7/8, 8/8 | 11.75 s | 11.53 s | 11.75 s |
| At most 2 body-coordinate changes/tick | 16/16 | 15/16 | 8/8, 7/8 | 11.96 s | 11.76 s | 11.96 s |
| Hold the first body row for 5 ticks | 16/16 | 10/16 | 4/8, 6/8 | 13.33 s | 12.32 s | 13.33 s |

| Body output rule | Executed rows | FSQ scalars | Visual decisions | Body write opportunities | Changed coordinates | Adjacent-bin change rate | Joint accel. RMS |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Native V4 | 9,399 | 601,536 | 1,886 | 9,399 | 12,413 | 2.067% | 2.357 rad/s² |
| At most 2 body-coordinate changes/tick | 9,571 | 612,544 | 1,921 | 9,571 | 11,255 | 1.840% | 2.150 rad/s² |
| Hold the first body row for 5 ticks | 10,661 | 682,304 | 2,136 | 2,136 | 9,427 | 1.384% | 2.034 rad/s² |

The cap ranks absolute bin error against the last body row actually applied and breaks ties by lower coordinate index. Every arm writes the complete first body row at reset. The hold keeps the first body row of each camera decision for up to 100 ms. All of the native dense rows remain available in the archives. Those 64 scalar codes per applied row are distinct from the count of coordinates whose values changed.

- At most 2 body-coordinate changes/tick produced 1 native-only, 1 variant-only placements on matched starts. Qualified lifts were 0 native-only, 0 variant-only.
- Hold the first body row for 5 ticks produced 5 native-only, 0 variant-only placements on matched starts. Qualified lifts were 0 native-only, 0 variant-only.

All 48 physical tapes were replayed independently without policy inference or rendering. Exact matches covered 29,631 applied body targets, finger pairs and measured velocities, 29,679 full native states including reset, and all terminal scores. Every paired physical reset was identical. Complete initial public packets were identical on 16/16 three-way comparisons. Both original public practice-seed tapes also reproduced all 1,105 archived body targets, hand commands and native state trajectories.

Each trial ran until strict placement, physical fall or 15 simulated seconds. The success-only column excludes failures. The failure-charged column assigns each failed start the full 15 seconds. The adjacent-bin change rate pools all 64 comparisons between neighboring applied rows within an episode. Acceleration pools 29 measured joint velocities across 100 ms differences from tick 5 onward. The finite study describes these 16 layouts and this controller.

The [complete per-start ledger](per_start.csv) covers every outcome and control hash. The [aggregate table](method_by_shape.csv) includes shape-specific costs and outcome denominators. The [protocol](protocol.json) registers the 64-bit starts and the published tests before rollout. [Raw measurements](results.json).

## Reproduction

Use the public tabletop task source at the exact revision in the protocol. Populate `snapshot/` from its environment and solution directories, retaining their names. Build the public task Docker image, or use the exact local image ID recorded in the protocol. The checksum ledger binds the simulator, V4 actor, decoder and both original practice tapes. The included `run.sh` mounts the two published controls from `../maintainer_review/public_seed7`; this directory can point to the portable archive’s `known/` folder. In an empty results directory, run `bash run.sh CPU calibrate`, then `bash run.sh CPU panel` with one or two separate available CPU IDs. Run `python summarize.py` after every paired tape has an independent replay receipt.

During source calibration, a vectorized independent recomputation of the seed-7 box acceleration gave 2.4244210149176575 rad/s² versus the registered per-row accumulator value of 2.4244210149176557. All original state and target hashes matched. Before opening the first new start, the verifier was changed to use the registered per-row operation and ordered scalar addition. The methods and cases remained as registered. The original source-only attempt and both verifier identities are retained.
